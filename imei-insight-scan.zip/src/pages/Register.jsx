import React, { useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { createPageUrl } from "@/utils";
import { Shield } from "lucide-react";

export default function Register() {
  useEffect(() => {
    base44.auth.redirectToLogin(createPageUrl("Dashboard"));
  }, []);

  return (
    <div className="min-h-screen bg-background flex items-center justify-center">
      <div className="text-center">
        <div className="w-12 h-12 rounded-2xl gradient-btn flex items-center justify-center mx-auto mb-4 shadow-lg">
          <Shield className="w-6 h-6 text-white" />
        </div>
        <p className="text-muted-foreground text-sm">Redirecting to sign up...</p>
      </div>
    </div>
  );
}