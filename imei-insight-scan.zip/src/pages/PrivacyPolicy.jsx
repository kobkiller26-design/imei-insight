import React from "react";
import { Lock } from "lucide-react";

export default function PrivacyPolicy() {
  return (
    <div className="min-h-screen bg-[#F8FAFC] py-12 px-4">
      <div className="max-w-3xl mx-auto">
        <div className="flex items-center gap-3 mb-8">
          <div className="w-10 h-10 rounded-xl gradient-btn flex items-center justify-center">
            <Lock className="w-5 h-5 text-white" />
          </div>
          <div>
            <h1 className="text-2xl font-bold text-foreground">Privacy Policy</h1>
            <p className="text-sm text-muted-foreground">Last updated: March 2026</p>
          </div>
        </div>

        <div className="bg-card rounded-2xl border border-border p-8 space-y-6 text-sm leading-relaxed">
          {[
            {
              title: "1. Information We Collect",
              content: "We collect information you provide directly: your email address, name, and IMEI numbers you submit for checking. We also collect usage data such as check history and payment records."
            },
            {
              title: "2. How We Use Your Information",
              content: "We use your information to provide the IMEI checking service, process payments, maintain your check history, send service-related emails, and improve our platform."
            },
            {
              title: "3. IMEI Data",
              content: "IMEI numbers you submit are sent to our third-party data provider (IMEICheck API) to retrieve device information. We store the results in your account history. We do not sell your IMEI data to third parties."
            },
            {
              title: "4. Payment Data",
              content: "Payment processing is handled by Stripe. We do not store your full credit card details. We retain records of transactions including amounts and dates for accounting purposes."
            },
            {
              title: "5. Data Sharing",
              content: "We do not sell your personal information. We share data only with service providers necessary to operate our platform (Stripe for payments, IMEICheck for lookups) and as required by law."
            },
            {
              title: "6. Data Retention",
              content: "We retain your account data while your account is active. Check history is retained for 2 years. You may request deletion of your account and data by contacting us."
            },
            {
              title: "7. Security",
              content: "We implement industry-standard security measures including encrypted connections (HTTPS) and secure API key management. No method of transmission is 100% secure."
            },
            {
              title: "8. Your Rights",
              content: "You have the right to access, correct, or delete your personal data. To exercise these rights, please contact us through our Contact page."
            },
            {
              title: "9. Cookies",
              content: "We use essential cookies to maintain your login session. We do not use tracking or advertising cookies."
            },
            {
              title: "10. Contact",
              content: "For privacy questions or data requests, please contact us through our Contact page."
            }
          ].map(({ title, content }) => (
            <div key={title}>
              <h2 className="font-bold text-foreground mb-2">{title}</h2>
              <p className="text-muted-foreground">{content}</p>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}