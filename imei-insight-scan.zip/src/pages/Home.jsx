import React, { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { base44 } from "@/api/base44Client";
import { Search, Lock, Globe, Zap, CheckCircle, ArrowRight, Smartphone, Star, Database } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";

const features = [
  { icon: Zap, title: "Instant Results", desc: "Get real-time device information in seconds" },
  { icon: Lock, title: "Secure & Private", desc: "Server-side processing, zero third-party sharing" },
  { icon: Globe, title: "Global Coverage", desc: "Check devices from carriers worldwide" },
  { icon: Database, title: "Accurate Data", desc: "Access to extensive carrier and device databases" }
];

const checks = [
  "Blacklist / Stolen Status",
  "Carrier & Network Info",
  "SIM Lock Status",
  "Warranty Information",
  "Device Brand & Model",
  "Country of Origin"
];

const trustItems = [
  { icon: CheckCircle, text: "Secure Checks" },
  { icon: Zap, text: "Instant Results" },
  { icon: Database, text: "Global Database" },
  { icon: Star, text: "Trusted by Thousands" }
];

const plans = [
  { name: "Starter", price: 5, credits: 10, description: "Perfect for occasional users" },
  { name: "Pro", price: 15, credits: 50, popular: true, description: "Most popular choice" },
  { name: "Business", price: 40, credits: 200, description: "For bulk operations" }
];

export default function Home() {
  const [imeiInput, setImeiInput] = useState("");
  const [user, setUser] = useState(null);
  const navigate = useNavigate();

  React.useEffect(() => {
    base44.auth.me().then(setUser).catch(() => setUser(null));
  }, []);

  const handleCheckIMEI = () => {
    if (imeiInput.trim()) {
      if (!user) {
        base44.auth.redirectToLogin(createPageUrl("ImeiCheck"));
      } else {
        navigate(createPageUrl("ImeiCheck"));
      }
    }
  };

  return (
    <div className="min-h-screen bg-background">
      {/* Hero Section */}
      <section className="relative overflow-hidden pt-20 pb-32 px-4">
        <div className="absolute top-0 right-0 w-[600px] h-[600px] bg-primary rounded-full blur-3xl -translate-y-1/2 translate-x-1/3 pointer-events-none opacity-10" />
        
        <div className="relative max-w-4xl mx-auto text-center">
          <h1 className="text-5xl sm:text-6xl md:text-7xl font-bold text-foreground tracking-tight mb-6 leading-tight">
            The #1 IMEI Checker
            <span className="block text-primary">for Any Device</span>
          </h1>
          
          <p className="text-lg text-muted-foreground mb-10 max-w-2xl mx-auto leading-relaxed">
            Instantly verify any device's IMEI. Get blacklist status, carrier info, warranty details, SIM lock status, and complete device specifications in seconds.
          </p>
          
          {/* IMEI Input */}
          <div className="max-w-md mx-auto mb-10">
            <div className="flex gap-2">
              <Input
                placeholder="Enter IMEI number..."
                value={imeiInput}
                onChange={(e) => setImeiInput(e.target.value)}
                onKeyPress={(e) => e.key === 'Enter' && handleCheckIMEI()}
                className="bg-card border-border placeholder:text-muted-foreground"
              />
              <Button onClick={handleCheckIMEI} className="gradient-btn text-white border-0 px-6">
                <Search className="w-4 h-4" />
              </Button>
            </div>
          </div>

          {/* Action Buttons */}
          <div className="flex flex-col sm:flex-row gap-3 justify-center mb-12">
            <Button size="lg" className="gradient-btn text-white border-0 h-12 px-8 text-base font-semibold" asChild>
              <Link to={createPageUrl("ImeiCheck")}>
                <Search className="w-4 h-4 mr-2" />
                Check IMEI Now
              </Link>
            </Button>
            <Button size="lg" variant="outline" className="h-12 px-8 text-base border-primary/30 hover:bg-primary/10" asChild>
              <Link to={createPageUrl("Pricing")}>
                View Pricing
                <ArrowRight className="w-4 h-4 ml-2" />
              </Link>
            </Button>
          </div>

          {/* Trust Indicators */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 max-w-2xl mx-auto">
            {trustItems.map(({ icon: Icon, text }) => (
              <div key={text} className="flex flex-col items-center gap-2">
                <div className="w-10 h-10 rounded-lg bg-primary/20 flex items-center justify-center">
                  <Icon className="w-5 h-5 text-primary" />
                </div>
                <span className="text-xs font-medium text-muted-foreground text-center">{text}</span>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* What You Can Check */}
      <section className="py-20 px-4 bg-card/50 border-y border-border">
        <div className="max-w-4xl mx-auto">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-foreground mb-3">What Our IMEI Checker Reveals</h2>
            <p className="text-muted-foreground max-w-2xl mx-auto">Complete device intelligence in one verification</p>
          </div>
          <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
            {checks.map((item) => (
              <div key={item} className="flex items-center gap-3 p-4 rounded-lg bg-background/50 border border-border/50 hover:border-primary/30 transition-colors">
                <CheckCircle className="w-5 h-5 text-primary flex-shrink-0" />
                <span className="text-sm font-medium text-foreground">{item}</span>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Why Choose Us */}
      <section className="py-20 px-4 bg-background">
        <div className="max-w-4xl mx-auto">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-foreground mb-3">Why Choose IMEI Insight</h2>
            <p className="text-muted-foreground">Built for accuracy, speed, and reliability</p>
          </div>
          <div className="grid sm:grid-cols-2 gap-6">
            {features.map(({ icon: Icon, title, desc }) => (
              <div key={title} className="p-6 rounded-2xl bg-card border border-border/50 hover:border-primary/30 transition-all group">
                <div className="w-12 h-12 rounded-lg bg-primary/20 flex items-center justify-center mb-4 group-hover:bg-primary/30 transition-colors">
                  <Icon className="w-6 h-6 text-primary" />
                </div>
                <h3 className="font-semibold text-foreground mb-2">{title}</h3>
                <p className="text-sm text-muted-foreground leading-relaxed">{desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Pricing Section */}
      <section className="py-20 px-4 bg-card/50 border-y border-border">
        <div className="max-w-4xl mx-auto">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-foreground mb-3">Simple, Transparent Pricing</h2>
            <p className="text-muted-foreground max-w-2xl mx-auto">Buy credits once, use them whenever you need. No subscriptions, no expiration.</p>
          </div>
          <div className="grid md:grid-cols-3 gap-6">
            {plans.map((plan) => (
              <div key={plan.name} className={`relative rounded-2xl border-2 p-6 transition-all ${
                plan.popular 
                  ? "bg-background border-primary shadow-lg shadow-primary/20" 
                  : "bg-card border-border/50 hover:border-primary/30"
              }`}>
                {plan.popular && (
                  <div className="absolute -top-3 left-1/2 -translate-x-1/2">
                    <span className="gradient-btn text-white text-xs font-bold px-3 py-1 rounded-full">
                      <Star className="w-3 h-3 inline mr-1" />Popular
                    </span>
                  </div>
                )}
                <h3 className="font-bold text-foreground text-lg mb-1">{plan.name}</h3>
                <p className="text-xs text-muted-foreground mb-4">{plan.description}</p>
                <p className="text-3xl font-bold text-foreground mb-1">${plan.price}</p>
                <p className="text-sm text-muted-foreground mb-6">{plan.credits} IMEI checks</p>
                <Button
                  size="sm"
                  className={`w-full ${plan.popular ? "gradient-btn text-white border-0" : "border-primary/30 hover:bg-primary/10"}`}
                  variant={plan.popular ? "default" : "outline"}
                  asChild
                >
                  <Link to={createPageUrl("Pricing")}>Get Started</Link>
                </Button>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 px-4 bg-background">
        <div className="max-w-xl mx-auto">
          <div className="relative overflow-hidden p-8 rounded-3xl text-center" style={{background: "linear-gradient(135deg, #1E90FF 0%, #0B6FD8 100%)"}}>
            <div className="absolute inset-0 opacity-10" style={{backgroundImage: "radial-gradient(circle at 30% 50%, white 0%, transparent 60%)"}} />
            <Smartphone className="w-12 h-12 text-white/80 mx-auto mb-4 relative z-10" />
            <h2 className="text-2xl font-bold text-white mb-3 relative z-10">Check a Device's IMEI Now</h2>
            <p className="text-white/80 text-sm mb-6 relative z-10">Get instant blacklist status, carrier info, and complete device specifications.</p>
            <Button size="lg" className="bg-white text-primary hover:bg-white/90 font-semibold h-11 px-8 relative z-10" asChild>
              <Link to={createPageUrl("ImeiCheck")}>
                Start Checking <ArrowRight className="w-4 h-4 ml-2" />
              </Link>
            </Button>
          </div>
        </div>
      </section>
    </div>
  );
}