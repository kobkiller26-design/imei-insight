import React, { useEffect, useState } from "react";
import { base44 } from "@/api/base44Client";
import { History as HistoryIcon, Search, CheckCircle, AlertCircle, Clock, ChevronDown } from "lucide-react";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import ApiResponseDisplay from "@/components/imei/ApiResponseDisplay";

export default function History() {
  const [user, setUser] = useState(null);
  const [checks, setChecks] = useState([]);
  const [filteredChecks, setFilteredChecks] = useState([]);
  const [searchQuery, setSearchQuery] = useState("");
  const [statusFilter, setStatusFilter] = useState("all");
  const [expandedId, setExpandedId] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const init = async () => {
      try {
        const me = await base44.auth.me();
        if (!me) {
          base44.auth.redirectToLogin("/history");
          return;
        }
        setUser(me);

        const checksData = await base44.entities.ImeiCheck.filter(
          { user_id: me.id },
          "-created_date",
          100
        );
        setChecks(checksData);
        setFilteredChecks(checksData);
      } catch (error) {
        console.error("Failed to load history:", error);
      } finally {
        setLoading(false);
      }
    };

    init();
  }, []);

  useEffect(() => {
    let filtered = checks;

    // Search filter
    if (searchQuery.trim()) {
      const query = searchQuery.toLowerCase();
      filtered = filtered.filter(
        (check) =>
          check.imei.toLowerCase().includes(query) ||
          check.device_name?.toLowerCase().includes(query) ||
          check.brand?.toLowerCase().includes(query) ||
          check.model?.toLowerCase().includes(query)
      );
    }

    // Status filter
    if (statusFilter !== "all") {
      filtered = filtered.filter((check) => check.status === statusFilter);
    }

    setFilteredChecks(filtered);
  }, [searchQuery, statusFilter, checks]);

  const statusConfig = {
    success: { icon: CheckCircle, color: "text-green-500", bg: "bg-green-500/10", label: "Success" },
    pending: { icon: Clock, color: "text-yellow-500", bg: "bg-yellow-500/10", label: "Pending" },
    error: { icon: AlertCircle, color: "text-red-500", bg: "bg-red-500/10", label: "Error" }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center">
          <div className="w-12 h-12 rounded-lg bg-primary/20 flex items-center justify-center mx-auto mb-4 animate-pulse">
            <HistoryIcon className="w-6 h-6 text-primary" />
          </div>
          <p className="text-muted-foreground">Loading your check history...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background py-12 px-4">
      <div className="max-w-4xl mx-auto space-y-8">
        {/* Header */}
        <div>
          <h1 className="text-4xl font-bold text-foreground mb-2">Check History</h1>
          <p className="text-muted-foreground">View all your previous IMEI checks</p>
        </div>

        {/* Filters */}
        <div className="grid sm:grid-cols-2 gap-4">
          <div>
            <label className="block text-sm font-medium text-foreground mb-2">Search</label>
            <div className="relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
              <Input
                placeholder="Search IMEI, device name..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-10 bg-input border-border text-foreground placeholder:text-muted-foreground"
              />
            </div>
          </div>
          <div>
            <label className="block text-sm font-medium text-foreground mb-2">Status</label>
            <Select value={statusFilter} onValueChange={setStatusFilter}>
              <SelectTrigger className="bg-input border-border text-foreground">
                <SelectValue />
              </SelectTrigger>
              <SelectContent className="bg-card border-border">
                <SelectItem value="all">All Status</SelectItem>
                <SelectItem value="success">Success</SelectItem>
                <SelectItem value="pending">Pending</SelectItem>
                <SelectItem value="error">Error</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>

        {/* Results Count */}
        <p className="text-sm text-muted-foreground">
          Showing {filteredChecks.length} of {checks.length} checks
        </p>

        {/* History List */}
        <div className="space-y-3">
          {filteredChecks.length > 0 ? (
            filteredChecks.map((check) => {
              const config = statusConfig[check.status];
              const Icon = config.icon;
              const isExpanded = expandedId === check.id;

              return (
                <Card key={check.id} className="bg-card border-border overflow-hidden">
                  <button
                    onClick={() => setExpandedId(isExpanded ? null : check.id)}
                    className="w-full text-left hover:bg-background/50 transition-colors"
                  >
                    <CardContent className="pt-6 pb-4">
                      <div className="flex items-center justify-between gap-4">
                        <div className="flex items-center gap-4 flex-1 min-w-0">
                          <div className={`w-10 h-10 rounded-lg ${config.bg} flex items-center justify-center flex-shrink-0`}>
                            <Icon className={`w-5 h-5 ${config.color}`} />
                          </div>
                          <div className="flex-1 min-w-0">
                            <div className="flex items-center gap-2 mb-1">
                              <p className="font-medium text-foreground truncate">{check.imei}</p>
                              <Badge className={`${config.bg} ${config.color} border-0 text-xs`}>
                                {config.label}
                              </Badge>
                            </div>
                            <p className="text-sm text-muted-foreground truncate">
                              {check.device_name || check.brand || check.service_name || "Unknown device"}
                            </p>
                            <p className="text-xs text-muted-foreground">
                              {new Date(check.created_date).toLocaleDateString()} at {new Date(check.created_date).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}
                            </p>
                          </div>
                        </div>
                        <ChevronDown className={`w-4 h-4 text-muted-foreground flex-shrink-0 transition-transform ${
                          isExpanded ? "rotate-180" : ""
                        }`} />
                      </div>
                    </CardContent>
                  </button>

                  {/* Expanded Details */}
                  {isExpanded && (
                    <div className="border-t border-border bg-background/50 px-6 py-4">
                      {check.status === "success" ? (
                        <div className="space-y-4">
                          <ApiResponseDisplay resultJson={check.result_json} />
                        </div>
                      ) : (
                        <div>
                          <p className="text-sm text-destructive">{check.error_message || "An error occurred"}</p>
                        </div>
                      )}
                    </div>
                  )}
                </Card>
              );
            })
          ) : (
            <Card className="bg-card border-border">
              <CardContent className="pt-12 pb-12 text-center">
                <HistoryIcon className="w-12 h-12 text-muted-foreground mx-auto mb-4 opacity-30" />
                <p className="text-muted-foreground mb-2">No checks found</p>
                <p className="text-sm text-muted-foreground/70">
                  {searchQuery ? "Try adjusting your search filters" : "Start by checking an IMEI"}
                </p>
              </CardContent>
            </Card>
          )}
        </div>
      </div>
    </div>
  );
}