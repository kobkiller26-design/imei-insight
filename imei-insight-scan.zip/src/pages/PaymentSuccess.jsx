import React, { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { base44 } from "@/api/base44Client";
import { CheckCircle, Search, LayoutDashboard, Zap } from "lucide-react";
import { Button } from "@/components/ui/button";

export default function PaymentSuccess() {
  const [user, setUser] = useState(null);
  const [credits, setCredits] = useState(null);

  const params = new URLSearchParams(window.location.search);
  const creditsAdded = params.get("credits");
  const planName = params.get("plan");

  useEffect(() => {
    base44.auth.me().then((u) => {
      setUser(u);
      setCredits(u?.credits || 0);
    }).catch(() => null);
  }, []);

  return (
    <div className="min-h-screen bg-[#F8FAFC] flex items-center justify-center px-4 py-16">
      <div className="max-w-md w-full text-center">
        <div className="bg-card rounded-3xl border border-border p-10 card-shadow-lg">
          {/* Success icon */}
          <div className="w-20 h-20 rounded-full bg-emerald-50 flex items-center justify-center mx-auto mb-6">
            <CheckCircle className="w-10 h-10 text-emerald-500" />
          </div>

          <h1 className="text-2xl font-bold text-foreground mb-2">Payment Successful!</h1>
          <p className="text-muted-foreground mb-6">
            {creditsAdded && planName
              ? `${creditsAdded} credits from the ${planName} plan have been added to your account.`
              : "Your credits have been added to your account."}
          </p>

          {credits !== null && (
            <div className="bg-secondary rounded-2xl p-4 mb-7 flex items-center justify-center gap-3">
              <Zap className="w-5 h-5 text-primary" />
              <span className="font-bold text-foreground text-lg">{credits} credits</span>
              <span className="text-muted-foreground text-sm">available now</span>
            </div>
          )}

          <div className="flex flex-col gap-3">
            <Button className="gradient-btn text-white border-0 h-11 font-semibold" asChild>
              <Link to={createPageUrl("ImeiCheck")}>
                <Search className="w-4 h-4 mr-2" />
                Start Checking IMEIs
              </Link>
            </Button>
            <Button variant="outline" className="h-11" asChild>
              <Link to={createPageUrl("Dashboard")}>
                <LayoutDashboard className="w-4 h-4 mr-2" />
                Go to Dashboard
              </Link>
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
}