import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { Search, AlertCircle, Smartphone, Loader } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import ResultCard from "@/components/imei/ResultCard";
import { createPageUrl } from "@/utils";
import { useNavigate } from "react-router-dom";

const validateIMEI = (imei) => {
  const cleaned = imei.replace(/\D/g, "");
  return cleaned.length >= 14 && cleaned.length <= 16;
};

export default function ImeiCheck() {
  const navigate = useNavigate();
  const [imei, setImei] = useState("");
  const [user, setUser] = useState(null);
  const [services, setServices] = useState([]);
  const [selectedService, setSelectedService] = useState("");
  const [result, setResult] = useState(null);
  const [isChecking, setIsChecking] = useState(false);
  const [error, setError] = useState("");

  useEffect(() => {
    const init = async () => {
      try {
        const me = await base44.auth.me();
        if (!me) {
          base44.auth.redirectToLogin("/imei-check");
          return;
        }
        setUser(me);

        const servicesData = await base44.entities.Service.filter({ is_active: true });
        setServices(servicesData);
        if (servicesData.length > 0) {
          setSelectedService(servicesData[0].service_id);
        }
      } catch (err) {
        console.error("Init error:", err);
      }
    };
    init();
  }, []);

  const handleCheck = async () => {
    setError("");
    setResult(null);

    if (!imei.trim()) {
      setError("Please enter an IMEI number");
      return;
    }

    if (!validateIMEI(imei)) {
      setError("IMEI must be 14-16 digits");
      return;
    }

    if (!selectedService) {
      setError("Please select a service");
      return;
    }

    if (!user || user.credits <= 0) {
      setError("Insufficient credits. Please purchase credits first.");
      return;
    }

    setIsChecking(true);
    try {
      const response = await base44.functions.invoke("imeiCheck", {
        imei: imei.replace(/\D/g, ""),
        service_id: selectedService,
      });

      if (response.data) {
        setResult(response.data);
        // Update user credits
        const updatedUser = await base44.auth.me();
        setUser(updatedUser);
      }
    } catch (err) {
      setError(err.message || "Check failed. Please try again.");
    } finally {
      setIsChecking(false);
    }
  };

  return (
    <div className="min-h-screen bg-background py-12 px-4">
      <div className="max-w-4xl mx-auto space-y-8">
        {/* Header */}
        <div>
          <h1 className="text-4xl font-bold text-foreground mb-2">IMEI Checker</h1>
          <p className="text-muted-foreground">Enter any device IMEI to get instant verification</p>
        </div>

        {/* Credits Warning */}
        {user && user.credits <= 3 && (
          <div className={`p-4 rounded-lg border flex items-start gap-3 ${
            user.credits === 0
              ? "bg-red-500/10 border-red-500/30"
              : "bg-yellow-500/10 border-yellow-500/30"
          }`}>
            <AlertCircle className={`w-5 h-5 flex-shrink-0 mt-0.5 ${
              user.credits === 0 ? "text-red-500" : "text-yellow-500"
            }`} />
            <div>
              <p className={`font-medium ${user.credits === 0 ? "text-red-400" : "text-yellow-400"}`}>
                {user.credits === 0 ? "No credits available" : `Only ${user.credits} credit${user.credits !== 1 ? "s" : ""} left`}
              </p>
              <p className={`text-sm ${user.credits === 0 ? "text-red-400/80" : "text-yellow-400/80"}`}>
                {user.credits === 0 ? "Purchase credits to continue checking IMEIs" : "Consider purchasing more credits"}
              </p>
            </div>
          </div>
        )}

        {/* Check Form */}
        <Card className="bg-card border-border">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Search className="w-5 h-5 text-primary" />
              Check Device
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-6">
            {/* IMEI Input */}
            <div>
              <label className="block text-sm font-medium text-foreground mb-2">IMEI Number</label>
              <Input
                placeholder="Enter 14-16 digit IMEI..."
                value={imei}
                onChange={(e) => setImei(e.target.value)}
                onKeyPress={(e) => e.key === "Enter" && handleCheck()}
                disabled={isChecking}
                className="bg-input border-border text-foreground placeholder:text-muted-foreground"
              />
            </div>

            {/* Service Selection */}
            <div>
              <label className="block text-sm font-medium text-foreground mb-2">Service Type</label>
              <Select value={selectedService} onValueChange={setSelectedService} disabled={isChecking}>
                <SelectTrigger className="bg-input border-border text-foreground">
                  <SelectValue placeholder="Select service..." />
                </SelectTrigger>
                <SelectContent className="bg-card border-border">
                  {services.map((service) => (
                    <SelectItem key={service.service_id} value={service.service_id}>
                      <span className="text-foreground">{service.service_name}</span>
                      <span className="text-muted-foreground ml-2">
                        ({service.credits_required || service.price} credit{(service.credits_required || service.price) !== 1 ? "s" : ""})
                      </span>
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            {/* Error Message */}
            {error && (
              <div className="p-4 rounded-lg bg-destructive/10 border border-destructive/30 flex items-start gap-3">
                <AlertCircle className="w-5 h-5 text-destructive flex-shrink-0 mt-0.5" />
                <p className="text-destructive text-sm">{error}</p>
              </div>
            )}

            {/* Check Button */}
            <Button
              onClick={handleCheck}
              disabled={isChecking}
              size="lg"
              className="w-full gradient-btn text-white border-0 h-11"
            >
              {isChecking ? (
                <>
                  <Loader className="w-4 h-4 mr-2 animate-spin" />
                  Checking...
                </>
              ) : (
                <>
                  <Search className="w-4 h-4 mr-2" />
                  Check IMEI
                </>
              )}
            </Button>
          </CardContent>
        </Card>

        {/* Results */}
        {result && (
          <div className="space-y-4">
            <h2 className="text-lg font-bold text-foreground">Check Results</h2>
            <ResultCard 
              result={result} 
              onNewCheck={() => {
                setResult(null);
                setImei("");
                setError("");
              }}
              onNewService={() => {
                setResult(null);
                setImei("");
                setSelectedService("");
                setError("");
              }}
            />
          </div>
        )}
      </div>
    </div>
  );
}