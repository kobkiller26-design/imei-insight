import React from "react";
import { RotateCcw } from "lucide-react";

export default function RefundPolicy() {
  return (
    <div className="min-h-screen bg-[#F8FAFC] py-12 px-4">
      <div className="max-w-3xl mx-auto">
        <div className="flex items-center gap-3 mb-8">
          <div className="w-10 h-10 rounded-xl gradient-btn flex items-center justify-center">
            <RotateCcw className="w-5 h-5 text-white" />
          </div>
          <div>
            <h1 className="text-2xl font-bold text-foreground">Refund Policy</h1>
            <p className="text-sm text-muted-foreground">Last updated: March 2026</p>
          </div>
        </div>

        <div className="bg-card rounded-2xl border border-border p-8 space-y-6 text-sm leading-relaxed">
          {[
            {
              title: "1. Overview",
              content: "At IMEI Insight, we want you to be satisfied with your purchase. This Refund Policy outlines when and how refunds may be issued for credit purchases."
            },
            {
              title: "2. Unused Credits",
              content: "If you have purchased credits and have not used them, you may request a full refund within 7 days of your purchase date. To request a refund, please contact us through the Contact page with your purchase details."
            },
            {
              title: "3. Used Credits",
              content: "Credits that have already been used to perform IMEI checks are non-refundable. Each IMEI check consumes 1 credit, and results are delivered instantly upon completion."
            },
            {
              title: "4. Partial Refunds",
              content: "If you have partially used a credit package within the 7-day window, a partial refund may be issued for the unused portion at our discretion. Contact us to discuss your situation."
            },
            {
              title: "5. Technical Issues",
              content: "If a check fails due to a technical error on our end and a credit was deducted, we will automatically restore the credit to your account. If this does not happen, please contact our support team."
            },
            {
              title: "6. Refund Process",
              content: "Approved refunds are processed back to your original payment method via Stripe. Refunds typically appear within 5–10 business days depending on your bank or card issuer."
            },
            {
              title: "7. How to Request",
              content: "To request a refund, email us at support@imeiinsight.com or use the Contact page. Include your account email and Stripe receipt number. We aim to respond within 24 hours."
            },
            {
              title: "8. Exceptions",
              content: "Refunds will not be issued for purchases where fraudulent or abusive activity is detected, or where terms of service have been violated."
            }
          ].map(({ title, content }) => (
            <div key={title}>
              <h2 className="font-bold text-foreground mb-2">{title}</h2>
              <p className="text-muted-foreground">{content}</p>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}