import React, { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { base44 } from "@/api/base44Client";
import { Check, Zap, Star, Building2, ArrowRight } from "lucide-react";
import { Button } from "@/components/ui/button";

const plans = [
  {
    name: "Starter",
    price: 5,
    credits: 10,
    price_id: "price_1T8GEVBKoCShLu5sQREbBJPi",
    icon: Zap,
    color: "from-blue-500 to-indigo-600",
    features: ["10 IMEI checks", "All check types", "Full device details", "Check history", "Email support"],
    popular: false
  },
  {
    name: "Pro",
    price: 15,
    credits: 50,
    price_id: "price_1T8GEVBKoCShLu5sbd2dvWlw",
    icon: Star,
    color: "from-indigo-500 to-purple-600",
    features: ["50 IMEI checks", "All check types", "Full device details", "Check history", "Priority support", "Bulk checking"],
    popular: true
  },
  {
    name: "Business",
    price: 40,
    credits: 200,
    price_id: "price_1T8GEVBKoCShLu5slFSAK5hA",
    icon: Building2,
    color: "from-purple-500 to-pink-600",
    features: ["200 IMEI checks", "All check types", "Full device details", "Check history", "Priority support", "Bulk checking", "API access"],
    popular: false
  }
];

export default function Pricing() {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(null);

  useEffect(() => {
    base44.auth.me().then(setUser).catch(() => setUser(null));
  }, []);

  const handlePurchase = async (plan) => {
    if (!user) {
      base44.auth.redirectToLogin(createPageUrl("Pricing"));
      return;
    }

    if (window.self !== window.top) {
      alert("Checkout is only available from the published app. Please open the app in a new tab.");
      return;
    }

    setLoading(plan.price_id);
    try {
      const response = await base44.functions.invoke("createCheckout", {
        price_id: plan.price_id,
        success_url: `${window.location.origin}${createPageUrl("PaymentSuccess")}?session_id={CHECKOUT_SESSION_ID}&credits=${plan.credits}&plan=${plan.name}`,
        cancel_url: `${window.location.origin}${createPageUrl("Pricing")}`
      });
      if (response.data.url) {
        window.location.href = response.data.url;
      }
    } catch (err) {
      alert("Failed to start checkout. Please try again.");
    } finally {
      setLoading(null);
    }
  };

  return (
    <div className="min-h-screen bg-background py-16 px-4">
      <div className="max-w-5xl mx-auto">
        {/* Header */}
        <div className="text-center mb-12">
          <div className="inline-flex items-center gap-2 bg-primary/20 text-primary text-xs font-semibold px-3 py-1.5 rounded-full mb-4 border border-primary/30">
            <Zap className="w-3 h-3" />
            Simple, transparent pricing
          </div>
          <h1 className="text-4xl font-bold text-foreground mb-3">
            Buy Credits, Check IMEIs
          </h1>
          <p className="text-muted-foreground text-lg max-w-md mx-auto">
            Pay once, use whenever. No subscriptions, no hidden fees. Credits never expire.
          </p>
        </div>

        {/* Plans */}
        <div className="grid md:grid-cols-3 gap-6 mb-12">
          {plans.map((plan) => {
            const Icon = plan.icon;
            const isLoading = loading === plan.price_id;
            return (
              <div
                key={plan.name}
                className={`relative rounded-3xl border-2 p-7 flex flex-col transition-all ${
                  plan.popular ? "bg-background border-primary shadow-lg shadow-primary/20 scale-105" : "bg-card border-border hover:border-primary/30"
                }`}
              >
                {plan.popular && (
                  <div className="absolute -top-3.5 left-1/2 -translate-x-1/2">
                    <span className="gradient-btn text-white text-xs font-bold px-4 py-1.5 rounded-full shadow-md">
                      Most Popular
                    </span>
                  </div>
                )}

                <div className={`w-12 h-12 rounded-2xl bg-gradient-to-br ${plan.color} flex items-center justify-center mb-5 shadow-lg`}>
                  <Icon className="w-6 h-6 text-white" />
                </div>

                <h2 className="text-xl font-bold text-foreground mb-1">{plan.name}</h2>
                <p className="text-muted-foreground text-sm mb-4">{plan.credits} IMEI checks</p>

                <div className="mb-6">
                  <span className="text-4xl font-bold text-foreground">${plan.price}</span>
                  <span className="text-muted-foreground text-sm ml-1">one-time</span>
                  <p className="text-xs text-muted-foreground mt-1">${(plan.price / plan.credits).toFixed(2)} per check</p>
                </div>

                <ul className="space-y-2.5 mb-7 flex-1">
                  {plan.features.map((f) => (
                    <li key={f} className="flex items-center gap-2.5 text-sm text-foreground">
                      <Check className="w-4 h-4 text-primary flex-shrink-0" />
                      {f}
                    </li>
                  ))}
                </ul>

                <Button
                  className={`w-full h-11 font-semibold ${plan.popular ? "gradient-btn text-white border-0" : ""}`}
                  variant={plan.popular ? "default" : "outline"}
                  onClick={() => handlePurchase(plan)}
                  disabled={!!loading}
                >
                  {isLoading ? "Redirecting..." : `Get ${plan.credits} Credits`}
                  {!isLoading && <ArrowRight className="w-4 h-4 ml-1" />}
                </Button>
              </div>
            );
          })}
        </div>

        {/* FAQ / notes */}
        <div className="text-center">
          <p className="text-sm text-muted-foreground">
            Credits never expire · Secure payments via Stripe · Instant credit delivery
          </p>
        </div>
      </div>
    </div>
  );
}