import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { Mail, MessageSquare, Send, CheckCircle } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";

export default function Contact() {
  const [form, setForm] = useState({ name: "", email: "", subject: "", message: "" });
  const [sending, setSending] = useState(false);
  const [sent, setSent] = useState(false);

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!form.name || !form.email || !form.message) return;
    setSending(true);
    try {
      await base44.integrations.Core.SendEmail({
        to: form.email,
        subject: `[IMEI Insight Contact] ${form.subject || "Message from " + form.name}`,
        body: `Name: ${form.name}\nEmail: ${form.email}\nSubject: ${form.subject}\n\nMessage:\n${form.message}`
      });
      setSent(true);
    } catch (err) {
      alert("Failed to send message. Please try again.");
    } finally {
      setSending(false);
    }
  };

  return (
    <div className="min-h-screen bg-[#F8FAFC] py-16 px-4">
      <div className="max-w-xl mx-auto">
        <div className="text-center mb-10">
          <div className="w-14 h-14 rounded-2xl gradient-btn flex items-center justify-center mx-auto mb-4 shadow-lg">
            <MessageSquare className="w-7 h-7 text-white" />
          </div>
          <h1 className="text-3xl font-bold text-foreground mb-2">Contact Us</h1>
          <p className="text-muted-foreground">Have a question or need help? We'll get back to you within 24 hours.</p>
        </div>

        {sent ? (
          <div className="bg-card rounded-3xl border border-border p-10 text-center card-shadow">
            <CheckCircle className="w-14 h-14 text-emerald-500 mx-auto mb-4" />
            <h2 className="text-xl font-bold text-foreground mb-2">Message Sent!</h2>
            <p className="text-muted-foreground">Thanks for reaching out. We'll respond to {form.email} shortly.</p>
          </div>
        ) : (
          <div className="bg-card rounded-3xl border border-border p-8 card-shadow">
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="grid sm:grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="name" className="text-xs font-semibold uppercase tracking-wide text-muted-foreground">Name *</Label>
                  <Input
                    id="name"
                    className="mt-1.5 h-11"
                    placeholder="Your name"
                    value={form.name}
                    onChange={e => setForm({...form, name: e.target.value})}
                    required
                  />
                </div>
                <div>
                  <Label htmlFor="email" className="text-xs font-semibold uppercase tracking-wide text-muted-foreground">Email *</Label>
                  <Input
                    id="email"
                    type="email"
                    className="mt-1.5 h-11"
                    placeholder="you@example.com"
                    value={form.email}
                    onChange={e => setForm({...form, email: e.target.value})}
                    required
                  />
                </div>
              </div>
              <div>
                <Label htmlFor="subject" className="text-xs font-semibold uppercase tracking-wide text-muted-foreground">Subject</Label>
                <Input
                  id="subject"
                  className="mt-1.5 h-11"
                  placeholder="What's this about?"
                  value={form.subject}
                  onChange={e => setForm({...form, subject: e.target.value})}
                />
              </div>
              <div>
                <Label htmlFor="message" className="text-xs font-semibold uppercase tracking-wide text-muted-foreground">Message *</Label>
                <textarea
                  id="message"
                  className="mt-1.5 w-full min-h-[140px] rounded-xl border border-input bg-background px-4 py-3 text-sm resize-none focus:outline-none focus:ring-2 focus:ring-ring"
                  placeholder="Tell us how we can help..."
                  value={form.message}
                  onChange={e => setForm({...form, message: e.target.value})}
                  required
                />
              </div>
              <Button
                type="submit"
                className="w-full h-11 gradient-btn text-white border-0 font-semibold"
                disabled={sending}
              >
                {sending ? "Sending..." : <><Send className="w-4 h-4 mr-2" />Send Message</>}
              </Button>
            </form>
          </div>
        )}

        <div className="mt-8 text-center">
          <div className="flex items-center justify-center gap-2 text-sm text-muted-foreground">
            <Mail className="w-4 h-4" />
            <span>You can also reach us at support@imeiinsight.com</span>
          </div>
        </div>
      </div>
    </div>
  );
}