import React, { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { base44 } from "@/api/base44Client";
import { Shield, Zap, History, ArrowRight, CheckCircle, AlertCircle, Clock } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";

export default function Dashboard() {
  const [user, setUser] = useState(null);
  const [checks, setChecks] = useState([]);
  const [purchases, setPurchases] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const loadData = async () => {
      try {
        const me = await base44.auth.me();
        if (!me) {
          base44.auth.redirectToLogin(createPageUrl("Dashboard"));
          return;
        }
        setUser(me);

        const checksData = await base44.entities.ImeiCheck.filter({ user_id: me.id }, "-created_date", 5);
        setChecks(checksData);

        const purchasesData = await base44.entities.CreditPurchase.filter({ user_id: me.id }, "-created_date", 5);
        setPurchases(purchasesData);
      } catch (error) {
        console.error("Failed to load dashboard data:", error);
      } finally {
        setLoading(false);
      }
    };

    loadData();
  }, []);

  if (loading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center">
          <div className="w-12 h-12 rounded-lg bg-primary/20 flex items-center justify-center mx-auto mb-4 animate-pulse">
            <Shield className="w-6 h-6 text-primary" />
          </div>
          <p className="text-muted-foreground">Loading your dashboard...</p>
        </div>
      </div>
    );
  }

  const credits = user?.credits ?? 0;
  const totalChecks = checks.length;
  const successChecks = checks.filter(c => c.status === "success").length;
  const successRate = totalChecks > 0 ? ((successChecks / totalChecks) * 100).toFixed(1) : 0;

  const statusConfig = {
    success: { icon: CheckCircle, color: "text-green-500", bg: "bg-green-500/10", label: "Success" },
    pending: { icon: Clock, color: "text-yellow-500", bg: "bg-yellow-500/10", label: "Pending" },
    error: { icon: AlertCircle, color: "text-red-500", bg: "bg-red-500/10", label: "Error" }
  };

  return (
    <div className="min-h-screen bg-background py-12 px-4">
      <div className="max-w-6xl mx-auto space-y-8">
        {/* Header */}
        <div>
          <h1 className="text-4xl font-bold text-foreground mb-2">Dashboard</h1>
          <p className="text-muted-foreground">Welcome back, {user?.full_name || user?.email}</p>
        </div>

        {/* Stats */}
        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4">
          <Card className="bg-card border-border">
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground mb-1">Credits Balance</p>
                  <p className="text-3xl font-bold text-foreground">{credits}</p>
                </div>
                <div className={`w-12 h-12 rounded-lg flex items-center justify-center ${
                  credits === 0 ? "bg-red-500/10" : credits <= 3 ? "bg-yellow-500/10" : "bg-primary/10"
                }`}>
                  <Zap className={`w-6 h-6 ${
                    credits === 0 ? "text-red-500" : credits <= 3 ? "text-yellow-500" : "text-primary"
                  }`} />
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="bg-card border-border">
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground mb-1">Total Checks</p>
                  <p className="text-3xl font-bold text-foreground">{totalChecks}</p>
                </div>
                <div className="w-12 h-12 rounded-lg bg-primary/10 flex items-center justify-center">
                  <History className="w-6 h-6 text-primary" />
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="bg-card border-border">
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground mb-1">Success Rate</p>
                  <p className="text-3xl font-bold text-foreground">{successRate}%</p>
                </div>
                <div className="w-12 h-12 rounded-lg bg-green-500/10 flex items-center justify-center">
                  <CheckCircle className="w-6 h-6 text-green-500" />
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="bg-card border-border">
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground mb-1">Total Spent</p>
                  <p className="text-3xl font-bold text-foreground">${purchases.reduce((sum, p) => sum + (p.amount_paid || 0), 0).toFixed(2)}</p>
                </div>
                <div className="w-12 h-12 rounded-lg bg-blue-500/10 flex items-center justify-center">
                  <Shield className="w-6 h-6 text-blue-500" />
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Action Buttons */}
        <div className="grid sm:grid-cols-2 gap-4">
          <Button size="lg" className="gradient-btn text-white border-0 h-12 justify-center" asChild>
            <Link to={createPageUrl("ImeiCheck")}>
              <Shield className="w-4 h-4 mr-2" />
              Check IMEI
            </Link>
          </Button>
          <Button size="lg" variant="outline" className="h-12 border-primary/30 hover:bg-primary/10" asChild>
            <Link to={createPageUrl("Pricing")}>
              <Zap className="w-4 h-4 mr-2" />
              Buy Credits
            </Link>
          </Button>
        </div>

        {/* Recent Activity */}
        <div className="grid lg:grid-cols-2 gap-8">
          {/* Recent Checks */}
          <Card className="bg-card border-border">
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle className="flex items-center gap-2">
                  <History className="w-5 h-5 text-primary" />
                  Recent Checks
                </CardTitle>
                <Link to={createPageUrl("History")} className="text-primary text-sm hover:underline flex items-center gap-1">
                  View All <ArrowRight className="w-3 h-3" />
                </Link>
              </div>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {checks.length > 0 ? (
                  checks.map((check) => {
                    const config = statusConfig[check.status];
                    const Icon = config.icon;
                    return (
                      <div key={check.id} className="flex items-start justify-between p-3 rounded-lg bg-background/50 border border-border/50">
                        <div className="flex items-start gap-3 flex-1">
                          <div className={`w-8 h-8 rounded-lg ${config.bg} flex items-center justify-center flex-shrink-0 mt-0.5`}>
                            <Icon className={`w-4 h-4 ${config.color}`} />
                          </div>
                          <div className="flex-1 min-w-0">
                            <p className="text-sm font-medium text-foreground truncate">{check.imei}</p>
                            <p className="text-xs text-muted-foreground">{check.service_name}</p>
                          </div>
                        </div>
                        <Badge className={`${config.bg} ${config.color} border-0 text-xs`}>{config.label}</Badge>
                      </div>
                    );
                  })
                ) : (
                  <p className="text-sm text-muted-foreground text-center py-8">No checks yet. Start by checking an IMEI!</p>
                )}
              </div>
            </CardContent>
          </Card>

          {/* Credit Purchases */}
          <Card className="bg-card border-border">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Zap className="w-5 h-5 text-primary" />
                Credit Purchases
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {purchases.length > 0 ? (
                  purchases.map((purchase) => (
                    <div key={purchase.id} className="flex items-start justify-between p-3 rounded-lg bg-background/50 border border-border/50">
                      <div className="flex-1">
                        <p className="text-sm font-medium text-foreground">${purchase.amount_paid}</p>
                        <p className="text-xs text-muted-foreground">{purchase.credits_added} credits</p>
                      </div>
                      <Badge className={`border-0 text-xs ${
                        purchase.status === "completed" ? "bg-green-500/10 text-green-500" :
                        purchase.status === "pending" ? "bg-yellow-500/10 text-yellow-500" :
                        "bg-red-500/10 text-red-500"
                      }`}>
                        {purchase.status}
                      </Badge>
                    </div>
                  ))
                ) : (
                  <p className="text-sm text-muted-foreground text-center py-8">No purchases yet. Buy credits to get started!</p>
                )}
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}