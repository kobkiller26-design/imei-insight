import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { createPageUrl } from "@/utils";
import { BarChart3, Users, DollarSign, Settings } from "lucide-react";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import ProfitTab from "../components/admin/ProfitTab";
import UserCreditManager from "../components/admin/UserCreditManager";
import ServicesManager from "../components/admin/ServicesManager";

export default function AdminDashboard() {
  const [user, setUser] = useState(null);
  const [checks, setChecks] = useState([]);
  const [purchases, setPurchases] = useState([]);

  useEffect(() => {
    base44.auth.me().then(setUser).catch(() => {
      window.location.href = createPageUrl("Login");
    });

    Promise.all([
      base44.entities.ImeiCheck.list(),
      base44.entities.CreditPurchase.list()
    ]).then(([c, p]) => {
      setChecks(c);
      setPurchases(p);
    }).catch(err => console.error('Failed to load data:', err));
  }, []);

  if (!user) return null;
  if (user?.role !== 'admin') {
    window.location.href = createPageUrl("Home");
    return null;
  }

  return (
    <div className="min-h-screen bg-[#F8FAFC] py-8 px-4">
      <div className="max-w-6xl mx-auto">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-foreground mb-1">Admin Dashboard</h1>
          <p className="text-muted-foreground">Manage services, users, and view analytics</p>
        </div>

        {/* Tabs */}
        <Tabs defaultValue="services" className="w-full">
          <TabsList className="grid w-full grid-cols-3 bg-card border border-border rounded-lg p-1">
            <TabsTrigger value="services" className="flex items-center gap-2">
              <Settings className="w-4 h-4" />
              <span className="hidden sm:inline">Services</span>
            </TabsTrigger>
            <TabsTrigger value="profit" className="flex items-center gap-2">
              <BarChart3 className="w-4 h-4" />
              <span className="hidden sm:inline">Profit Analytics</span>
            </TabsTrigger>
            <TabsTrigger value="users" className="flex items-center gap-2">
              <Users className="w-4 h-4" />
              <span className="hidden sm:inline">Credit Manager</span>
            </TabsTrigger>
          </TabsList>

          <div className="mt-6">
            {/* Services Tab */}
            <TabsContent value="services" className="space-y-4">
              <ServicesManager />
            </TabsContent>

            {/* Profit Tab */}
            <TabsContent value="profit" className="space-y-4">
              <ProfitTab checks={checks} purchases={purchases} />
            </TabsContent>

            {/* Users Tab */}
            <TabsContent value="users" className="space-y-4">
              <UserCreditManager />
            </TabsContent>
          </div>
        </Tabs>
      </div>
    </div>
  );
}