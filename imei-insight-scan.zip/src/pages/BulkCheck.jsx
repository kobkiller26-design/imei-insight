import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { AlertCircle, Upload, Loader, CheckCircle, Clock } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

const validateIMEI = (imei) => {
  const cleaned = imei.replace(/\D/g, "");
  return cleaned.length >= 14 && cleaned.length <= 16;
};

export default function BulkCheck() {
  const [user, setUser] = useState(null);
  const [services, setServices] = useState([]);
  const [selectedService, setSelectedService] = useState("");
  const [imeiList, setImeiList] = useState("");
  const [isProcessing, setIsProcessing] = useState(false);
  const [results, setResults] = useState([]);
  const [error, setError] = useState("");

  useEffect(() => {
    const init = async () => {
      try {
        const me = await base44.auth.me();
        if (!me) {
          base44.auth.redirectToLogin("/bulk-check");
          return;
        }
        setUser(me);

        const servicesData = await base44.entities.Service.filter({ is_active: true });
        setServices(servicesData);
        if (servicesData.length > 0) {
          setSelectedService(servicesData[0].service_id);
        }
      } catch (err) {
        console.error("Init error:", err);
      }
    };
    init();
  }, []);

  const handleBulkCheck = async () => {
    setError("");
    setResults([]);

    const imeis = imeiList
      .split("\n")
      .map((line) => line.trim())
      .filter((line) => line);

    if (imeis.length === 0) {
      setError("Please enter at least one IMEI");
      return;
    }

    const invalidImeis = imeis.filter((i) => !validateIMEI(i));
    if (invalidImeis.length > 0) {
      setError(`Invalid IMEIs: ${invalidImeis.slice(0, 3).join(", ")}${invalidImeis.length > 3 ? "..." : ""}`);
      return;
    }

    if (!selectedService) {
      setError("Please select a service");
      return;
    }

    if (!user || user.credits < imeis.length) {
      setError(`Insufficient credits. You need ${imeis.length} credits but have ${user?.credits || 0}`);
      return;
    }

    setIsProcessing(true);
    try {
      const response = await base44.functions.invoke("bulkImeiCheck", {
        imeis,
        service_id: selectedService,
      });

      if (response.data?.results) {
        setResults(response.data.results);
        // Update user credits
        const updatedUser = await base44.auth.me();
        setUser(updatedUser);
      }
    } catch (err) {
      setError(err.message || "Bulk check failed. Please try again.");
    } finally {
      setIsProcessing(false);
    }
  };

  const completedCount = results.filter((r) => r.status !== "pending").length;
  const successCount = results.filter((r) => r.status === "success").length;
  const errorCount = results.filter((r) => r.status === "error").length;

  return (
    <div className="min-h-screen bg-background py-12 px-4">
      <div className="max-w-4xl mx-auto space-y-8">
        {/* Header */}
        <div>
          <h1 className="text-4xl font-bold text-foreground mb-2">Bulk IMEI Check</h1>
          <p className="text-muted-foreground">Check multiple IMEIs at once</p>
        </div>

        {/* Credits Warning */}
        {user && user.credits <= 5 && (
          <div className={`p-4 rounded-lg border flex items-start gap-3 ${
            user.credits === 0
              ? "bg-red-500/10 border-red-500/30"
              : "bg-yellow-500/10 border-yellow-500/30"
          }`}>
            <AlertCircle className={`w-5 h-5 flex-shrink-0 mt-0.5 ${
              user.credits === 0 ? "text-red-500" : "text-yellow-500"
            }`} />
            <div>
              <p className={`font-medium ${user.credits === 0 ? "text-red-400" : "text-yellow-400"}`}>
                {user.credits === 0 ? "No credits available" : `Only ${user.credits} credits left`}
              </p>
            </div>
          </div>
        )}

        {/* Input Form */}
        <Card className="bg-card border-border">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Upload className="w-5 h-5 text-primary" />
              Enter IMEIs
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-6">
            {/* IMEI Input */}
            <div>
              <label className="block text-sm font-medium text-foreground mb-2">
                IMEIs (one per line)
              </label>
              <textarea
                placeholder="Enter IMEIs, one per line..."
                value={imeiList}
                onChange={(e) => setImeiList(e.target.value)}
                disabled={isProcessing}
                rows={8}
                className="w-full px-4 py-3 rounded-lg bg-input border border-border text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary/50 resize-none disabled:opacity-50"
              />
              <p className="text-xs text-muted-foreground mt-2">
                {imeiList.split("\n").filter((l) => l.trim()).length} IMEI{imeiList.split("\n").filter((l) => l.trim()).length !== 1 ? "s" : ""} detected
              </p>
            </div>

            {/* Service Selection */}
            <div>
              <label className="block text-sm font-medium text-foreground mb-2">Service Type</label>
              <Select value={selectedService} onValueChange={setSelectedService} disabled={isProcessing}>
                <SelectTrigger className="bg-input border-border text-foreground">
                  <SelectValue placeholder="Select service..." />
                </SelectTrigger>
                <SelectContent className="bg-card border-border">
                  {services.map((service) => (
                    <SelectItem key={service.service_id} value={service.service_id}>
                      {service.service_name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            {/* Error Message */}
            {error && (
              <div className="p-4 rounded-lg bg-destructive/10 border border-destructive/30 flex items-start gap-3">
                <AlertCircle className="w-5 h-5 text-destructive flex-shrink-0 mt-0.5" />
                <p className="text-destructive text-sm">{error}</p>
              </div>
            )}

            {/* Check Button */}
            <Button
              onClick={handleBulkCheck}
              disabled={isProcessing}
              size="lg"
              className="w-full gradient-btn text-white border-0 h-11"
            >
              {isProcessing ? (
                <>
                  <Loader className="w-4 h-4 mr-2 animate-spin" />
                  Processing...
                </>
              ) : (
                <>
                  <Upload className="w-4 h-4 mr-2" />
                  Process Bulk Check
                </>
              )}
            </Button>
          </CardContent>
        </Card>

        {/* Results */}
        {results.length > 0 && (
          <div className="space-y-4">
            {/* Progress Summary */}
            <div className="grid sm:grid-cols-4 gap-4">
              <Card className="bg-card border-border">
                <CardContent className="pt-6">
                  <div className="text-center">
                    <p className="text-sm text-muted-foreground mb-1">Total</p>
                    <p className="text-2xl font-bold text-foreground">{results.length}</p>
                  </div>
                </CardContent>
              </Card>
              <Card className="bg-card border-border">
                <CardContent className="pt-6">
                  <div className="text-center">
                    <p className="text-sm text-muted-foreground mb-1">Success</p>
                    <p className="text-2xl font-bold text-green-500">{successCount}</p>
                  </div>
                </CardContent>
              </Card>
              <Card className="bg-card border-border">
                <CardContent className="pt-6">
                  <div className="text-center">
                    <p className="text-sm text-muted-foreground mb-1">Failed</p>
                    <p className="text-2xl font-bold text-red-500">{errorCount}</p>
                  </div>
                </CardContent>
              </Card>
              <Card className="bg-card border-border">
                <CardContent className="pt-6">
                  <div className="text-center">
                    <p className="text-sm text-muted-foreground mb-1">Progress</p>
                    <p className="text-2xl font-bold text-primary">{completedCount}/{results.length}</p>
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Results List */}
            <h3 className="text-lg font-bold text-foreground">Results</h3>
            <div className="space-y-2">
              {results.map((result, idx) => (
                <Card key={idx} className="bg-card border-border">
                  <CardContent className="pt-4 pb-4">
                    <div className="flex items-center justify-between gap-4">
                      <div className="flex items-center gap-3 flex-1 min-w-0">
                        <div className={`w-10 h-10 rounded-lg flex items-center justify-center flex-shrink-0 ${
                          result.status === "success" ? "bg-green-500/10" :
                          result.status === "error" ? "bg-red-500/10" :
                          "bg-yellow-500/10"
                        }`}>
                          {result.status === "success" && <CheckCircle className="w-5 h-5 text-green-500" />}
                          {result.status === "error" && <AlertCircle className="w-5 h-5 text-red-500" />}
                          {result.status === "pending" && <Clock className="w-5 h-5 text-yellow-500 animate-spin" />}
                        </div>
                        <div className="flex-1 min-w-0">
                          <p className="font-medium text-foreground truncate">{result.imei}</p>
                          <p className="text-sm text-muted-foreground">
                            {result.device_name || result.brand || "Processing..."}
                          </p>
                        </div>
                      </div>
                      <Badge className={`border-0 text-xs ${
                        result.status === "success" ? "bg-green-500/10 text-green-500" :
                        result.status === "error" ? "bg-red-500/10 text-red-500" :
                        "bg-yellow-500/10 text-yellow-500"
                      }`}>
                        {result.status}
                      </Badge>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}