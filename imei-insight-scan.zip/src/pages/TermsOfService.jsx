import React from "react";
import { Shield } from "lucide-react";

export default function TermsOfService() {
  return (
    <div className="min-h-screen bg-[#F8FAFC] py-12 px-4">
      <div className="max-w-3xl mx-auto">
        <div className="flex items-center gap-3 mb-8">
          <div className="w-10 h-10 rounded-xl gradient-btn flex items-center justify-center">
            <Shield className="w-5 h-5 text-white" />
          </div>
          <div>
            <h1 className="text-2xl font-bold text-foreground">Terms of Service</h1>
            <p className="text-sm text-muted-foreground">Last updated: March 2026</p>
          </div>
        </div>

        <div className="bg-card rounded-2xl border border-border p-8 space-y-6 text-sm text-foreground leading-relaxed">
          {[
            {
              title: "1. Acceptance of Terms",
              content: "By accessing or using IMEI Insight, you agree to be bound by these Terms of Service. If you do not agree to these terms, please do not use our service."
            },
            {
              title: "2. Service Description",
              content: "IMEI Insight provides IMEI verification services for informational purposes only. We use third-party data providers and cannot guarantee 100% accuracy of results. Results should be used as a guide only and not as a definitive legal record."
            },
            {
              title: "3. Credit System",
              content: "Our service operates on a prepaid credit system. Credits are purchased in advance and deducted per IMEI check. Credits are non-refundable once used. Unused credits do not expire."
            },
            {
              title: "4. Payments",
              content: "All payments are processed securely through Stripe. We do not store your payment card details. Purchases are final. Refunds may be issued at our discretion for unused credits within 7 days of purchase."
            },
            {
              title: "5. Acceptable Use",
              content: "You agree to use IMEI Insight only for lawful purposes. You must not use our service to facilitate fraud, check devices you do not own or have explicit permission to check, or attempt to circumvent our systems."
            },
            {
              title: "6. Privacy",
              content: "We collect and process data as described in our Privacy Policy. IMEI numbers you submit are used solely to perform checks and are stored in your check history."
            },
            {
              title: "7. Limitation of Liability",
              content: "IMEI Insight is provided 'as is'. We make no warranties about the accuracy or completeness of results. We shall not be liable for any damages arising from your use of or reliance on our service."
            },
            {
              title: "8. Changes to Terms",
              content: "We may update these terms at any time. Continued use of the service after changes constitutes acceptance of the new terms."
            },
            {
              title: "9. Contact",
              content: "For questions about these terms, please contact us through our Contact page."
            }
          ].map(({ title, content }) => (
            <div key={title}>
              <h2 className="font-bold text-foreground mb-2">{title}</h2>
              <p className="text-muted-foreground">{content}</p>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}