import React, { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { base44 } from "@/api/base44Client";
import { Shield, Menu, X, Search, History, Settings, LogOut, ChevronDown, Zap } from "lucide-react";
import { Button } from "@/components/ui/button";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";

const navLinks = [
  { label: "IMEI Check", page: "ImeiCheck", icon: Search },
  { label: "History", page: "History", icon: History },
  { label: "Pricing", page: "Pricing", icon: Zap },
];

export default function Layout({ children, currentPageName }) {
  const [user, setUser] = useState(null);
  const [menuOpen, setMenuOpen] = useState(false);

  useEffect(() => {
    base44.auth.me().then(setUser).catch(() => setUser(null));
  }, []);

  const handleLogout = () => {
    base44.auth.logout(createPageUrl("Home"));
  };

  const isActive = (page) => currentPageName === page;
  const credits = user?.credits ?? 0;

  return (
    <div className="min-h-screen bg-background">
      {/* Navbar */}
      <nav className="sticky top-0 z-50 bg-background/95 backdrop-blur border-b border-border">
        <div className="max-w-6xl mx-auto px-4 sm:px-6">
          <div className="flex items-center justify-between h-16">
            {/* Logo */}
            <Link to={createPageUrl("Home")} className="flex items-center gap-2.5 group">
              <div className="w-8 h-8 rounded-lg bg-primary flex items-center justify-center shadow-sm group-hover:shadow-md transition-shadow">
                <Shield className="w-4 h-4 text-white" />
              </div>
              <div>
                <span className="font-bold text-foreground text-sm">IMEI Insight</span>
                <p className="text-[10px] text-muted-foreground leading-none hidden sm:block">Device Intelligence</p>
              </div>
            </Link>

            {/* Desktop Nav */}
            <div className="hidden md:flex items-center gap-1">
              {navLinks.map(({ label, page, icon: Icon }) => (
                <Link
                  key={page}
                  to={createPageUrl(page)}
                  className={`flex items-center gap-1.5 px-3 py-2 rounded-lg text-sm font-medium transition-all ${
                    isActive(page)
                      ? "bg-primary/20 text-primary"
                      : "text-muted-foreground hover:text-foreground hover:bg-primary/10"
                  }`}
                >
                  <Icon className="w-3.5 h-3.5" />
                  {label}
                </Link>
              ))}
              {user?.role === "admin" && (
                <Link
                  to={createPageUrl("AdminDashboard")}
                  className={`flex items-center gap-1.5 px-3 py-2 rounded-lg text-sm font-medium transition-all ${
                    isActive("AdminDashboard")
                      ? "bg-primary/20 text-primary"
                      : "text-muted-foreground hover:text-foreground hover:bg-primary/10"
                  }`}
                >
                  <Settings className="w-3.5 h-3.5" />
                  Admin
                </Link>
              )}
            </div>

            {/* Right side */}
            <div className="flex items-center gap-2">
              {user ? (
                <>
                  {/* Credits badge */}
                  <Link
                    to={createPageUrl("Pricing")}
                    className={`hidden sm:flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold transition-all ${
                      credits === 0
                        ? "bg-red-500/20 text-red-300 hover:bg-red-500/30"
                        : credits <= 3
                        ? "bg-yellow-500/20 text-yellow-300 hover:bg-yellow-500/30"
                        : "bg-primary/20 text-primary hover:bg-primary/30"
                    }`}
                  >
                    <Zap className="w-3 h-3" />
                    {credits} credits
                  </Link>

                  <DropdownMenu>
                    <DropdownMenuTrigger asChild>
                      <Button variant="ghost" className="flex items-center gap-2 h-9 px-2 text-foreground hover:bg-primary/10">
                        <Avatar className="w-7 h-7">
                          <AvatarFallback className="bg-primary text-white text-xs font-semibold">
                            {user.full_name?.[0]?.toUpperCase() || user.email?.[0]?.toUpperCase() || "U"}
                          </AvatarFallback>
                        </Avatar>
                        <span className="hidden sm:block text-sm font-medium max-w-[120px] truncate">
                          {user.full_name || user.email}
                        </span>
                        <ChevronDown className="w-3.5 h-3.5 text-muted-foreground" />
                      </Button>
                    </DropdownMenuTrigger>
                    <DropdownMenuContent align="end" className="w-48 bg-card border-border">
                      <div className="px-3 py-2">
                        <p className="text-sm font-medium truncate">{user.full_name || "User"}</p>
                        <p className="text-xs text-muted-foreground truncate">{user.email}</p>
                        <p className="text-xs font-semibold text-primary mt-1">{credits} credits</p>
                      </div>
                      <DropdownMenuSeparator className="bg-border" />
                      <DropdownMenuItem asChild>
                        <Link to={createPageUrl("Dashboard")} className="flex items-center gap-2">
                          <Shield className="w-4 h-4" /> Dashboard
                        </Link>
                      </DropdownMenuItem>
                      <DropdownMenuItem asChild>
                        <Link to={createPageUrl("History")} className="flex items-center gap-2">
                          <History className="w-4 h-4" /> History
                        </Link>
                      </DropdownMenuItem>
                      <DropdownMenuItem asChild>
                        <Link to={createPageUrl("Pricing")} className="flex items-center gap-2">
                          <Zap className="w-4 h-4" /> Buy Credits
                        </Link>
                      </DropdownMenuItem>
                      {user?.role === "admin" && (
                        <DropdownMenuItem asChild>
                          <Link to={createPageUrl("AdminDashboard")} className="flex items-center gap-2">
                            <Settings className="w-4 h-4" /> Admin
                          </Link>
                        </DropdownMenuItem>
                      )}
                      <DropdownMenuSeparator className="bg-border" />
                      <DropdownMenuItem onClick={handleLogout} className="text-destructive focus:text-destructive">
                        <LogOut className="w-4 h-4 mr-2" /> Sign out
                      </DropdownMenuItem>
                    </DropdownMenuContent>
                  </DropdownMenu>
                </>
              ) : (
                <div className="flex items-center gap-2">
                  <Button variant="ghost" size="sm" className="text-muted-foreground hover:text-foreground hover:bg-primary/10" asChild>
                    <Link to={createPageUrl("Login")}>Sign in</Link>
                  </Button>
                  <Button size="sm" className="gradient-btn text-white border-0" asChild>
                    <Link to={createPageUrl("Register")}>Get started</Link>
                  </Button>
                </div>
              )}

              {/* Mobile menu toggle */}
              <button
                className="md:hidden p-2 rounded-lg text-muted-foreground hover:text-foreground hover:bg-primary/10"
                onClick={() => setMenuOpen(!menuOpen)}
              >
                {menuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
              </button>
            </div>
          </div>
        </div>

        {/* Mobile Menu */}
        {menuOpen && (
          <div className="md:hidden border-t border-border bg-background px-4 py-3 space-y-1">
            {navLinks.map(({ label, page, icon: Icon }) => (
              <Link
                key={page}
                to={createPageUrl(page)}
                onClick={() => setMenuOpen(false)}
                className={`flex items-center gap-2 px-3 py-2.5 rounded-lg text-sm font-medium transition-all ${
                  isActive(page)
                    ? "bg-primary/20 text-primary"
                    : "text-muted-foreground hover:text-foreground hover:bg-primary/10"
                }`}
              >
                <Icon className="w-4 h-4" />
                {label}
              </Link>
            ))}
            {user && (
              <Link
                to={createPageUrl("Pricing")}
                onClick={() => setMenuOpen(false)}
                className="flex items-center gap-2 px-3 py-2.5 rounded-lg text-sm font-medium text-muted-foreground hover:text-foreground hover:bg-primary/10"
              >
                <Zap className="w-4 h-4" />
                {credits} credits
              </Link>
            )}
            {user?.role === "admin" && (
              <Link
                to={createPageUrl("AdminDashboard")}
                onClick={() => setMenuOpen(false)}
                className="flex items-center gap-2 px-3 py-2.5 rounded-lg text-sm font-medium text-muted-foreground hover:text-foreground hover:bg-primary/10"
              >
                <Settings className="w-4 h-4" /> Admin
              </Link>
            )}
          </div>
        )}
      </nav>

      {/* Page content */}
      <main>{children}</main>

      {/* Footer */}
      <footer className="bg-card border-t border-border mt-20 py-12">
        <div className="max-w-6xl mx-auto px-4 sm:px-6">
          <div className="grid sm:grid-cols-4 gap-8 mb-8">
            <div>
              <div className="flex items-center gap-2 mb-3">
                <div className="w-6 h-6 rounded-lg bg-primary flex items-center justify-center">
                  <Shield className="w-3.5 h-3.5 text-white" />
                </div>
                <span className="font-bold text-foreground text-sm">IMEI Insight</span>
              </div>
              <p className="text-xs text-muted-foreground leading-relaxed">Instant device intelligence. Check any IMEI for complete device information.</p>
            </div>
            <div>
              <p className="text-xs font-semibold text-primary uppercase tracking-wide mb-3">Product</p>
              <div className="space-y-2">
                {[
                  { label: "IMEI Check", page: "ImeiCheck" },
                  { label: "Pricing", page: "Pricing" },
                  { label: "Dashboard", page: "Dashboard" },
                  { label: "History", page: "History" },
                ].map(({ label, page }) => (
                  <Link key={page} to={createPageUrl(page)} className="block text-xs text-muted-foreground hover:text-primary transition-colors">{label}</Link>
                ))}
              </div>
            </div>
            <div>
              <p className="text-xs font-semibold text-primary uppercase tracking-wide mb-3">Legal</p>
              <div className="space-y-2">
                {[
                  { label: "Terms of Service", page: "TermsOfService" },
                  { label: "Privacy Policy", page: "PrivacyPolicy" },
                  { label: "Refund Policy", page: "RefundPolicy" },
                  { label: "Contact", page: "Contact" },
                ].map(({ label, page }) => (
                  <Link key={page} to={createPageUrl(page)} className="block text-xs text-muted-foreground hover:text-primary transition-colors">{label}</Link>
                ))}
              </div>
            </div>
            <div>
              <p className="text-xs font-semibold text-primary uppercase tracking-wide mb-3">Status</p>
              <div className="space-y-2">
                <p className="text-xs text-muted-foreground">✓ All systems operational</p>
                <p className="text-xs text-muted-foreground">99.9% uptime guaranteed</p>
              </div>
            </div>
          </div>
          <div className="border-t border-border pt-6 text-center">
            <p className="text-xs text-muted-foreground">© 2026 IMEI Insight. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}