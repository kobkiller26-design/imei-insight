import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Code } from "lucide-react";

export default function ApiResponseDisplay({ resultJson }) {
  if (!resultJson) return null;

  let parsedData = resultJson;
  
  // Parse JSON string if needed
  if (typeof resultJson === "string") {
    try {
      parsedData = JSON.parse(resultJson);
    } catch (e) {
      return (
        <Card className="bg-card border-border">
          <CardHeader>
            <CardTitle className="text-lg flex items-center gap-2">
              <Code className="w-5 h-5 text-primary" />
              API Response
            </CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-sm text-muted-foreground">{resultJson}</p>
          </CardContent>
        </Card>
      );
    }
  }

  // Handle nested result object
  let responseData = parsedData;
  if (parsedData?.result && typeof parsedData.result === "object") {
    responseData = parsedData.result;
  }

  // If it's still an object, flatten it for display
  const fields = typeof responseData === "object" ? responseData : { data: responseData };

  // Map of field names to display labels
  const fieldLabels = {
    device_model: "Device Model",
    brand: "Brand",
    manufacturer: "Manufacturer",
    model: "Model",
    carrier: "Carrier",
    sim_lock: "SIM Lock Status",
    blacklist_status: "Blacklist Status",
    country: "Country",
    imei: "IMEI",
    serial_number: "Serial Number",
    serial: "Serial Number",
    activation_status: "Activation Status",
    warranty_status: "Warranty Status",
    network_type: "Network Type",
    device_name: "Device Name",
    device: "Device",
    color: "Color",
    release_date: "Release Date",
    fmi_status: "FMI Status",
    icloud_status: "iCloud Status",
    phone_number: "Phone Number",
    box_contents: "Box Contents"
  };

  // Filter and map fields
  const displayFields = Object.entries(fields)
    .filter(([key, value]) => value !== null && value !== undefined && value !== "")
    .map(([key, value]) => ({
      key,
      label: fieldLabels[key.toLowerCase()] || key.replace(/_/g, " ").split(" ").map(w => w.charAt(0).toUpperCase() + w.slice(1)).join(" "),
      value
    }));

  if (displayFields.length === 0) return null;

  return (
    <Card className="bg-card border-border">
      <CardHeader>
        <CardTitle className="text-lg flex items-center gap-2">
          <Code className="w-5 h-5 text-primary" />
          API Response Details
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-3">
          {displayFields.map(({ key, label, value }) => {
            // Format nested objects as JSON
            const displayValue = typeof value === "object" ? JSON.stringify(value) : String(value);
            
            return (
              <div key={key} className="flex justify-between text-sm border-b border-border/50 pb-3 last:border-0 last:pb-0">
                <span className="text-muted-foreground font-medium">{label}</span>
                <span className="font-mono text-foreground text-right max-w-xs truncate" title={displayValue}>
                  {displayValue}
                </span>
              </div>
            );
          })}
        </div>
      </CardContent>
    </Card>
  );
}