import React from "react";
import { CheckCircle, AlertCircle, Copy, MessageCircle, RefreshCw, Plus, Check, X } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { createPageUrl } from "@/utils";
import { Link } from "react-router-dom";

export default function ResultCard({ result, onNewCheck, onNewService }) {
  if (!result) return null;

  const isSuccess = result.status === "success";

  // Field mapping - maps API field names to display labels
  const fieldMappings = {
    model: "Model",
    brand: "Brand",
    device_name: "Device Name",
    imei: "IMEI Number",
    imei2: "IMEI2 Number",
    serial_number: "Serial Number",
    country: "Country",
    carrier: "Carrier",
    network_type: "Network",
    warranty_status: "Warranty Status",
    purchase_date: "Estimated Purchase Date",
    fmi_status: "Find My iPhone",
    blacklist_status: "Block Status",
    sim_lock: "SIM-Lock Status",
    phone_support: "Telephone Technical Support",
    repairs_coverage: "Repairs and Service Coverage",
    replaced_apple: "Replaced by Apple"
  };

  // Parse and flatten the API response to extract useful fields
  const parseResults = () => {
    const fields = {};
    const rawData = result.data || result.result || {};

    // First, try to get mapped fields from result object
    Object.keys(fieldMappings).forEach(key => {
      if (result[key] && result[key] !== "N/A" && result[key] !== "") {
        fields[fieldMappings[key]] = result[key];
      }
    });

    // Then extract any additional fields from raw data that aren't already mapped
    const processObject = (obj, prefix = "") => {
      Object.entries(obj).forEach(([key, value]) => {
        if (value === null || value === undefined || value === "" || key === "raw") return;
        
        const displayKey = fieldMappings[key] || formatFieldName(key);
        const fullKey = prefix ? `${prefix}.${displayKey}` : displayKey;

        if (typeof value === "object" && !Array.isArray(value)) {
          processObject(value, fullKey);
        } else if (typeof value === "string" || typeof value === "number" || typeof value === "boolean") {
          // Only add if not already mapped
          if (!fields[displayKey]) {
            fields[displayKey] = value;
          }
        }
      });
    };

    if (typeof rawData === "object") {
      processObject(rawData);
    }

    return fields;
  };

  // Format field names from snake_case to Title Case
  const formatFieldName = (str) => {
    return str
      .replace(/_/g, " ")
      .split(" ")
      .map(word => word.charAt(0).toUpperCase() + word.slice(1))
      .join(" ");
  };

  // Determine status color based on value
  const getStatusColor = (value) => {
    const normalized = String(value).toLowerCase().trim();
    
    // Green statuses
    if (["ok", "clean", "yes", "active", "unlocked", "off", "no", "success", "available", "valid"].includes(normalized)) {
      return "bg-green-500/15 text-green-400 border border-green-500/30";
    }
    // Red statuses
    if (["error", "failed", "blocked", "stolen", "blacklisted", "locked", "on"].includes(normalized)) {
      return "bg-red-500/15 text-red-400 border border-red-500/30";
    }
    // Gray/muted
    return "bg-secondary/50 text-muted-foreground border border-border";
  };

  // Get status icon
  const getStatusIcon = (value) => {
    const normalized = String(value).toLowerCase().trim();
    if (["ok", "clean", "yes", "active", "unlocked", "off", "no", "success"].includes(normalized)) {
      return Check;
    }
    if (["error", "failed", "blocked", "stolen"].includes(normalized)) {
      return X;
    }
    return null;
  };

  // Handle copy to clipboard
  const handleCopyResult = () => {
    const fields = parseResults();
    const resultText = Object.entries(fields)
      .map(([key, value]) => `${key}: ${value}`)
      .join("\n");
    
    navigator.clipboard.writeText(resultText);
    alert("Result copied to clipboard!");
  };

  // Handle WhatsApp share
  const handleWhatsApp = () => {
    const fields = parseResults();
    const resultText = Object.entries(fields)
      .map(([key, value]) => `${key}: ${value}`)
      .join("\n");
    
    const message = `IMEI Check Result:\n\n${resultText}`;
    window.open(`https://wa.me/?text=${encodeURIComponent(message)}`, "_blank");
  };

  const parsedFields = parseResults();
  const mainInfo = result.model || result.device_name || result.brand || "Device Information";

  return (
    <div className="space-y-4">
      {/* Status Header Card */}
      <Card className="bg-card/40 border-primary/20 backdrop-blur-sm">
        <CardContent className="pt-6">
          <div className="flex items-start gap-4 mb-4">
            <div className="flex-shrink-0">
              {isSuccess ? (
                <div className="w-12 h-12 rounded-lg bg-green-500/15 flex items-center justify-center border border-green-500/30">
                  <CheckCircle className="w-6 h-6 text-green-400" />
                </div>
              ) : (
                <div className="w-12 h-12 rounded-lg bg-red-500/15 flex items-center justify-center border border-red-500/30">
                  <AlertCircle className="w-6 h-6 text-red-400" />
                </div>
              )}
            </div>
            <div className="flex-1">
              <p className="text-xs text-muted-foreground font-medium mb-1">CHECK STATUS</p>
              <p className={`text-lg font-bold ${isSuccess ? "text-green-400" : "text-red-400"}`}>
                {isSuccess ? "Order Processed!" : "Check Failed"}
              </p>
              {result.imei && (
                <p className="text-xs text-muted-foreground mt-1 font-mono">{result.imei}</p>
              )}
            </div>
          </div>
        </CardContent>
      </Card>

      {isSuccess ? (
        <>
          {/* Results Card */}
          <Card className="bg-card/40 border-border/50 backdrop-blur-sm">
            <CardContent className="pt-6">
              {mainInfo && (
                <div className="mb-6 pb-4 border-b border-border/30">
                  <p className="text-sm text-muted-foreground font-medium mb-2">MODEL</p>
                  <p className="text-sm font-semibold text-foreground leading-relaxed">{mainInfo}</p>
                </div>
              )}

              {/* Results Grid */}
              <div className="space-y-3">
                {Object.entries(parsedFields).map(([label, value]) => {
                  // Skip model/device_name since it's already shown at top
                  if (["Model", "Device Name", "IMEI Number"].includes(label) && label !== "IMEI Number") {
                    return null;
                  }

                  const StatusIcon = getStatusIcon(value);
                  const isStatusField = [
                    "Warranty Status",
                    "Find My iPhone",
                    "Block Status",
                    "SIM-Lock Status",
                    "Telephone Technical Support",
                    "Repairs and Service Coverage"
                  ].includes(label);

                  return (
                    <div key={label} className="flex items-center justify-between py-2 px-2 rounded-lg hover:bg-secondary/20 transition-colors">
                      <span className="text-xs text-muted-foreground font-medium">{label}</span>
                      <div className="flex items-center gap-2">
                        {isStatusField ? (
                          <Badge className={`text-xs font-semibold ${getStatusColor(value)}`}>
                            {StatusIcon && <StatusIcon className="w-3 h-3 mr-1" />}
                            {value}
                          </Badge>
                        ) : (
                          <span className="text-sm font-semibold text-foreground text-right max-w-xs truncate">
                            {value}
                          </span>
                        )}
                      </div>
                    </div>
                  );
                })}
              </div>

              {/* Action Buttons */}
              <div className="mt-6 pt-4 border-t border-border/30 space-y-3">
                <Button
                  onClick={handleCopyResult}
                  className="w-full bg-secondary/50 hover:bg-secondary text-foreground border border-border/50"
                  size="sm"
                >
                  <Copy className="w-4 h-4 mr-2" />
                  Copy Result
                </Button>

                <Button
                  onClick={handleWhatsApp}
                  className="w-full bg-green-600 hover:bg-green-700 text-white border-0 font-semibold"
                  size="sm"
                >
                  <MessageCircle className="w-4 h-4 mr-2" />
                  SEND TO MY WHATSAPP
                </Button>

                <div className="grid grid-cols-2 gap-2">
                  <Button
                    onClick={onNewCheck}
                    className="bg-primary/20 hover:bg-primary/30 text-primary border border-primary/30"
                    size="sm"
                  >
                    <RefreshCw className="w-4 h-4 mr-1" />
                    NEW IMEI
                  </Button>
                  <Button
                    onClick={onNewService}
                    className="bg-primary/20 hover:bg-primary/30 text-primary border border-primary/30"
                    size="sm"
                  >
                    <Plus className="w-4 h-4 mr-1" />
                    NEW SERVICE
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        </>
      ) : (
        /* Error Card */
        <Card className="bg-red-500/10 border-red-500/30">
          <CardContent className="pt-6">
            <div className="flex items-start gap-3">
              <AlertCircle className="w-5 h-5 text-red-400 flex-shrink-0 mt-0.5" />
              <div className="flex-1">
                <p className="text-sm font-semibold text-red-400 mb-1">Check Failed</p>
                <p className="text-xs text-red-300/80">{result.error_message || "Unable to process this IMEI. Please try again."}</p>
              </div>
            </div>
            <div className="mt-4 pt-3 border-t border-red-500/20">
              <Button
                onClick={onNewCheck}
                className="w-full bg-red-500/20 hover:bg-red-500/30 text-red-400 border border-red-500/30"
                size="sm"
              >
                <RefreshCw className="w-4 h-4 mr-2" />
                Try Again
              </Button>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}