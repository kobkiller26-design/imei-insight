import React, { useEffect, useState } from "react";
import { base44 } from "@/api/base44Client";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Loader2 } from "lucide-react";

export default function ServiceSelector({ value, onChange, disabled }) {
  const [services, setServices] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    base44.entities.Service.filter({ is_active: true })
      .then(setServices)
      .catch(() => setServices([]))
      .finally(() => setLoading(false));
  }, []);

  if (loading) {
    return (
      <div className="flex items-center gap-2 h-10 px-3 border border-input rounded-lg bg-muted">
        <Loader2 className="w-4 h-4 animate-spin text-muted-foreground" />
        <span className="text-sm text-muted-foreground">Loading services...</span>
      </div>
    );
  }

  if (services.length === 0) {
    return (
      <div className="flex items-center gap-2 h-10 px-3 border border-input rounded-lg bg-muted">
        <span className="text-sm text-muted-foreground">No services available. Admin must add services first.</span>
      </div>
    );
  }

  return (
    <Select value={value} onValueChange={onChange} disabled={disabled}>
      <SelectTrigger className="h-10 bg-background">
        <SelectValue placeholder="Select a service..." />
      </SelectTrigger>
      <SelectContent>
        {services.map((s) => (
          <SelectItem key={s.id} value={s.service_id}>
            <div className="flex items-center justify-between gap-4 w-full">
              <span className="font-medium">{s.service_name}</span>
              {s.price !== undefined && s.price !== null && (
                <span className="text-xs text-muted-foreground ml-2">
                  {s.price === 0 ? "Free" : `$${s.price}`}
                </span>
              )}
            </div>
          </SelectItem>
        ))}
      </SelectContent>
    </Select>
  );
}