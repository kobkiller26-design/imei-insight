import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { RefreshCw, Plus, Edit2, Trash2, Loader2, AlertCircle, CheckCircle2, Upload, RotateCcw, Clock } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Switch } from "@/components/ui/switch";
import ServiceForm from "./ServiceForm";
import ServiceManagementTable from "./ServiceManagementTable";
import BulkImportDialog from "./BulkImportDialog";

export default function ServicesManager() {
  const [services, setServices] = useState([]);
  const [loading, setLoading] = useState(true);
  const [syncing, setSyncing] = useState(false);
  const [editing, setEditing] = useState(null);
  const [showForm, setShowForm] = useState(false);
  const [syncMessage, setSyncMessage] = useState(null);
  const [syncError, setSyncError] = useState(null);
  const [showBulkImport, setShowBulkImport] = useState(false);
  const [recalcLoading, setRecalcLoading] = useState(false);
  const [syncLogs, setSyncLogs] = useState([]);
  const [showLogs, setShowLogs] = useState(false);

  useEffect(() => {
    loadServices();
  }, []);

  const loadServices = async () => {
    setLoading(true);
    try {
      const data = await base44.entities.Service.list();
      setServices(data);
    } catch (err) {
      console.error('Failed to load services:', err);
    } finally {
      setLoading(false);
    }
  };

  const loadSyncLogs = async () => {
    try {
      const logs = await base44.entities.SyncLog.list('-created_date', 10);
      setSyncLogs(logs);
    } catch (err) {
      console.error('Failed to load sync logs:', err);
    }
  };

  const handleSync = async () => {
    setSyncing(true);
    setSyncMessage(null);
    setSyncError(null);
    try {
      const response = await base44.functions.invoke('syncDhruServices', {});
      if (response.data.success) {
        setSyncMessage(
          `Dhru sync successful: ${response.data.services_added} added, ${response.data.services_updated} updated, ${response.data.services_deactivated} deactivated`
        );
        loadServices();
      } else {
        setSyncError(response.data.error || 'Sync failed');
      }
    } catch (err) {
      setSyncError(err.response?.data?.error || err.message || 'Sync failed');
    } finally {
      setSyncing(false);
    }
  };

  const handleSaveService = async (formData) => {
    try {
      if (editing) {
        await base44.entities.Service.update(editing.id, formData);
      } else {
        await base44.entities.Service.create(formData);
      }
      setShowForm(false);
      setEditing(null);
      loadServices();
    } catch (err) {
      console.error('Failed to save service:', err);
    }
  };

  const handleDeleteService = async (serviceId) => {
    if (!window.confirm('Delete this service? This cannot be undone.')) return;
    try {
      await base44.entities.Service.delete(serviceId);
      loadServices();
    } catch (err) {
      console.error('Failed to delete service:', err);
    }
  };

  const handleToggleActive = async (service) => {
    try {
      await base44.entities.Service.update(service.id, {
        is_active: !service.is_active
      });
      loadServices();
    } catch (err) {
      console.error('Failed to toggle service:', err);
    }
  };

  const handleRecalculatePrices = async () => {
    setRecalcLoading(true);
    try {
      await base44.functions.invoke('recalculatePrices', {
        rule_type: 'tiered',
        rules: {
          cheap_threshold: 0.1,
          cheap_commission: 50,
          medium_threshold: 0.5,
          medium_commission: 30,
          expensive_commission: 20
        }
      });
      loadServices();
    } finally {
      setRecalcLoading(false);
    }
  };

  return (
    <div className="space-y-4">
      {/* Sync Section */}
      <div className="bg-card rounded-2xl border border-border p-5 card-shadow">
        <div className="flex items-center justify-between mb-3">
          <div>
            <h3 className="font-semibold text-foreground">Dhru API Synchronization</h3>
            <p className="text-xs text-muted-foreground mt-0.5">Automatically runs every 4 hours</p>
          </div>
          <Button
            size="sm"
            className="gradient-btn text-white border-0"
            onClick={handleSync}
            disabled={syncing}
          >
            {syncing ? (
              <><Loader2 className="w-3.5 h-3.5 mr-1.5 animate-spin" />Syncing Now...</>
            ) : (
              <><RefreshCw className="w-3.5 h-3.5 mr-1.5" />Sync Dhru Services Now</>
            )}
          </Button>
        </div>
        <p className="text-xs text-muted-foreground mb-3">Automatically fetch and update services from Dhru API. New services are synced every 4 hours automatically.</p>

        <div className="mb-3 flex gap-2">
          <Button
            size="sm"
            variant="outline"
            onClick={() => {
              setShowLogs(!showLogs);
              if (!showLogs) loadSyncLogs();
            }}
            className="gap-1"
          >
            <Clock className="w-3.5 h-3.5" />
            {showLogs ? 'Hide' : 'View'} Sync Logs
          </Button>
        </div>

        {showLogs && (
          <div className="mb-4 p-3 bg-secondary/20 rounded-lg border border-border/50">
            <p className="text-xs font-semibold text-foreground mb-2">Recent Sync History</p>
            <div className="space-y-2 max-h-64 overflow-y-auto">
              {syncLogs.length === 0 ? (
                <p className="text-xs text-muted-foreground">No sync logs yet</p>
              ) : (
                syncLogs.map((log) => (
                  <div key={log.id} className="text-xs text-muted-foreground p-2 bg-background/50 rounded border border-border/30">
                    <div className="flex items-center justify-between">
                      <span>{new Date(log.timestamp).toLocaleString()}</span>
                      <span className={log.status === 'success' ? 'text-green-400' : 'text-red-400'}>
                        {log.status === 'success' ? '✓' : '✗'}
                      </span>
                    </div>
                    <div className="text-xs">
                      +{log.services_added} | ↻{log.services_updated} | -{log.services_deactivated}
                    </div>
                    {log.errors && <div className="text-red-400 text-xs mt-1">{log.errors}</div>}
                  </div>
                ))
              )}
            </div>
          </div>
        )}

        {syncMessage && (
          <Alert className="py-2.5 border-green-200 bg-green-50 mb-3">
            <CheckCircle2 className="w-4 h-4 text-green-600" />
            <AlertDescription className="text-sm text-green-700">{syncMessage}</AlertDescription>
          </Alert>
        )}

        {syncError && (
          <Alert variant="destructive" className="py-2.5 mb-3">
            <AlertCircle className="w-4 h-4" />
            <AlertDescription className="text-sm">
              {syncError}
              {syncError.includes('API provider error') && (
                <div className="mt-2 text-xs">
                  <p><strong>Setup Required:</strong> Configure your IMEI API provider endpoint and credentials.</p>
                  <p>Contact your API provider for the correct endpoint URL and update environment variables.</p>
                </div>
              )}
            </AlertDescription>
          </Alert>
        )}
      </div>

      {/* New Service Management Table */}
      <div className="bg-card rounded-2xl border border-border p-5 card-shadow">
        <div className="flex items-center justify-between mb-4">
          <h3 className="font-semibold text-foreground">Service Management</h3>
          <div className="flex gap-2">
            <Button variant="outline" size="sm" onClick={() => setShowBulkImport(true)} className="gap-1">
              <Upload className="w-3.5 h-3.5" />
              Bulk Import
            </Button>
            <Button variant="outline" size="sm" onClick={handleRecalculatePrices} disabled={recalcLoading} className="gap-1">
              <RotateCcw className="w-3.5 h-3.5" />
              {recalcLoading ? 'Recalculating...' : 'Recalc Prices'}
            </Button>
          </div>
        </div>
        <ServiceManagementTable 
          services={services}
          onRefresh={loadServices}
        />
      </div>

      {/* Bulk Import Dialog */}
      <BulkImportDialog
        open={showBulkImport}
        onOpenChange={setShowBulkImport}
        onSuccess={loadServices}
      />

      {/* Old Services List (keeping for backward compatibility) */}
      <div className="bg-card rounded-2xl border border-border p-5 card-shadow">
        <div className="flex items-center justify-between mb-4">
          <h3 className="font-semibold text-foreground">IMEI Services ({services.length})</h3>
          <Button
            size="sm"
            className="gradient-btn text-white border-0"
            onClick={() => {
              setEditing(null);
              setShowForm(true);
            }}
          >
            <Plus className="w-3.5 h-3.5 mr-1.5" />Add Service
          </Button>
        </div>

        {showForm && (
          <div className="mb-4 p-4 bg-secondary rounded-xl border border-border">
            <ServiceForm
              service={editing}
              onSave={handleSaveService}
              onCancel={() => {
                setShowForm(false);
                setEditing(null);
              }}
            />
          </div>
        )}

        {loading ? (
          <div className="text-center py-6">
            <Loader2 className="w-5 h-5 animate-spin text-muted-foreground mx-auto" />
          </div>
        ) : services.length === 0 ? (
          <p className="text-sm text-muted-foreground text-center py-4">No services yet. Click "Sync Services from API" to add them.</p>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-border">
                  <th className="text-left py-2 px-3 text-xs font-semibold text-muted-foreground">Service</th>
                  <th className="text-left py-2 px-3 text-xs font-semibold text-muted-foreground">API ID</th>
                  <th className="text-right py-2 px-3 text-xs font-semibold text-muted-foreground">API Cost</th>
                  <th className="text-right py-2 px-3 text-xs font-semibold text-muted-foreground">Commission</th>
                  <th className="text-right py-2 px-3 text-xs font-semibold text-muted-foreground">Customer Price</th>
                  <th className="text-center py-2 px-3 text-xs font-semibold text-muted-foreground">Active</th>
                  <th className="text-right py-2 px-3 text-xs font-semibold text-muted-foreground">Actions</th>
                </tr>
              </thead>
              <tbody>
                {services.map(service => (
                  <tr key={service.id} className="border-b border-border last:border-0 hover:bg-secondary/30">
                    <td className="py-3 px-3 font-medium text-foreground">{service.service_name}</td>
                    <td className="py-3 px-3 text-foreground font-mono text-xs">{service.service_id}</td>
                    <td className="py-3 px-3 text-right text-foreground">${(service.api_cost || 0).toFixed(4)}</td>
                    <td className="py-3 px-3 text-right text-foreground">{service.commission_percentage || 50}%</td>
                    <td className="py-3 px-3 text-right font-semibold text-indigo-600">${(service.price || 0).toFixed(2)}</td>
                    <td className="py-3 px-3 text-center">
                      <Switch
                        checked={service.is_active ?? true}
                        onCheckedChange={() => handleToggleActive(service)}
                      />
                    </td>
                    <td className="py-3 px-3 text-right">
                      <div className="flex justify-end gap-1.5">
                        <Button
                          size="icon"
                          variant="ghost"
                          className="h-7 w-7"
                          onClick={() => {
                            setEditing(service);
                            setShowForm(true);
                          }}
                        >
                          <Edit2 className="w-3.5 h-3.5" />
                        </Button>
                        <Button
                          size="icon"
                          variant="ghost"
                          className="h-7 w-7 text-destructive hover:text-destructive"
                          onClick={() => handleDeleteService(service.id)}
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </Button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
}