import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Plus, Minus, Check } from "lucide-react";

export default function UserCreditManager({ user, onUpdated }) {
  const [amount, setAmount] = useState("");
  const [loading, setLoading] = useState(false);
  const [done, setDone] = useState(null);

  const apply = async (delta) => {
    const n = parseInt(amount);
    if (!n || n <= 0) return;
    setLoading(true);
    const current = user.credits || 0;
    const next = Math.max(0, current + delta * n);
    await base44.entities.User.update(user.id, { credits: next });
    setDone(delta > 0 ? `+${n}` : `-${n}`);
    setAmount("");
    setLoading(false);
    setTimeout(() => setDone(null), 2000);
    onUpdated();
  };

  return (
    <div className="flex items-center gap-1.5 flex-shrink-0">
      {done ? (
        <span className="text-xs font-semibold text-emerald-600 flex items-center gap-1">
          <Check className="w-3 h-3" />{done} credits
        </span>
      ) : (
        <>
          <Input
            type="number"
            min="1"
            value={amount}
            onChange={e => setAmount(e.target.value)}
            placeholder="#"
            className="h-7 w-14 text-xs text-center"
          />
          <Button size="icon" className="h-7 w-7 bg-emerald-500 hover:bg-emerald-600 text-white" onClick={() => apply(1)} disabled={loading || !amount}>
            <Plus className="w-3 h-3" />
          </Button>
          <Button size="icon" className="h-7 w-7 bg-red-500 hover:bg-red-600 text-white" onClick={() => apply(-1)} disabled={loading || !amount}>
            <Minus className="w-3 h-3" />
          </Button>
        </>
      )}
    </div>
  );
}