import React, { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Save, X } from "lucide-react";

export default function ServiceForm({ service, onSave, onCancel }) {
  const [form, setForm] = useState({
    service_name: service?.service_name || "",
    service_id: service?.service_id || "",
    api_cost: service?.api_cost ?? "",
    commission_percentage: service?.commission_percentage ?? 50,
    description: service?.description || "",
    category: service?.category || "",
    is_active: service?.is_active ?? true
  });

  const apiCost = parseFloat(form.api_cost) || 0;
  const commission = parseFloat(form.commission_percentage) || 0;
  const customerPrice = apiCost * (1 + commission / 100);

  const handleSave = () => {
    if (!form.service_name || !form.service_id) return;
    onSave({
      ...form,
      api_cost: apiCost,
      commission_percentage: commission,
      price: parseFloat(customerPrice.toFixed(4))
    });
  };

  return (
    <div className="space-y-3">
      <div className="grid sm:grid-cols-2 gap-3">
        <div>
          <Label className="text-xs">Service Name *</Label>
          <Input value={form.service_name} onChange={e => setForm({...form, service_name: e.target.value})} placeholder="e.g. Basic IMEI Check" className="mt-1 h-9 text-sm" />
        </div>
        <div>
          <Label className="text-xs">Service ID (API) *</Label>
          <Input value={form.service_id} onChange={e => setForm({...form, service_id: e.target.value})} placeholder="e.g. 1" className="mt-1 h-9 text-sm" />
        </div>
        <div>
          <Label className="text-xs">API Cost ($) — what you pay</Label>
          <Input type="number" step="0.0001" value={form.api_cost} onChange={e => setForm({...form, api_cost: e.target.value})} placeholder="0.00" className="mt-1 h-9 text-sm" />
        </div>
        <div>
          <Label className="text-xs">Commission %</Label>
          <Input type="number" step="1" value={form.commission_percentage} onChange={e => setForm({...form, commission_percentage: e.target.value})} placeholder="50" className="mt-1 h-9 text-sm" />
        </div>
        <div>
          <Label className="text-xs">Category</Label>
          <Input value={form.category} onChange={e => setForm({...form, category: e.target.value})} placeholder="e.g. Blacklist" className="mt-1 h-9 text-sm" />
        </div>
        <div className="flex items-center gap-3 pt-5">
          <div className="bg-indigo-50 border border-indigo-200 rounded-lg px-3 py-2 text-sm">
            <span className="text-muted-foreground text-xs">Customer Price: </span>
            <span className="font-bold text-indigo-700">${customerPrice.toFixed(2)}</span>
            <span className="text-xs text-muted-foreground ml-1">(cost × {(1 + commission/100).toFixed(2)}x)</span>
          </div>
        </div>
        <div className="sm:col-span-2">
          <Label className="text-xs">Description</Label>
          <Input value={form.description} onChange={e => setForm({...form, description: e.target.value})} placeholder="Brief description" className="mt-1 h-9 text-sm" />
        </div>
      </div>
      <div className="flex gap-2">
        <Button size="sm" className="gradient-btn text-white border-0" onClick={handleSave}>
          <Save className="w-3.5 h-3.5 mr-1.5" /> Save
        </Button>
        <Button size="sm" variant="outline" onClick={onCancel}>
          <X className="w-3.5 h-3.5 mr-1.5" /> Cancel
        </Button>
      </div>
    </div>
  );
}