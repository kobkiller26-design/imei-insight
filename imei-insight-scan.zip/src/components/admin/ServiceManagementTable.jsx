import React, { useState, useMemo } from 'react';
import { base44 } from '@/api/base44Client';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Checkbox } from '@/components/ui/checkbox';
import { Badge } from '@/components/ui/badge';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Search, Edit2, Trash2, Download, Upload, Percent } from 'lucide-react';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogHeader,
  AlertDialogTitle,
} from '@/components/ui/alert-dialog';

const BRANDS = ['All Brands', 'Apple', 'Samsung', 'Xiaomi', 'Huawei', 'Motorola', 'Google Pixel', 'OnePlus', 'Honor'];
const CATEGORIES = ['Apple', 'Samsung', 'Xiaomi', 'Huawei', 'Motorola', 'Google Pixel', 'OnePlus', 'Carrier Checks', 'Blacklist Checks', 'Warranty / Activation', 'FMI / iCloud', 'Converters', 'Other'];

export default function ServiceManagementTable({ services, onRefresh }) {
  const [search, setSearch] = useState('');
  const [selectedBrand, setSelectedBrand] = useState('All Brands');
  const [selectedCategory, setSelectedCategory] = useState('');
  const [priceRange, setPriceRange] = useState({ min: 0, max: 10 });
  const [selectedServices, setSelectedServices] = useState(new Set());
  const [showBulkEdit, setShowBulkEdit] = useState(false);
  const [bulkEditData, setBulkEditData] = useState({});
  const [loading, setLoading] = useState(false);
  const [showEditAllCommission, setShowEditAllCommission] = useState(false);
  const [globalCommission, setGlobalCommission] = useState(50);

  const filteredServices = useMemo(() => {
    return services.filter(s => {
      const matchSearch = s.service_name?.toLowerCase().includes(search.toLowerCase()) ||
                         s.service_id?.includes(search);
      const matchBrand = selectedBrand === 'All Brands' || s.brand === selectedBrand;
      const matchCategory = !selectedCategory || s.category === selectedCategory;
      const matchPrice = (s.api_cost ?? 0) >= priceRange.min && (s.api_cost ?? 0) <= priceRange.max;
      return matchSearch && matchBrand && matchCategory && matchPrice;
    });
  }, [services, search, selectedBrand, selectedCategory, priceRange]);

  const handleSelectAll = (checked) => {
    if (checked) {
      setSelectedServices(new Set(filteredServices.map(s => s.id)));
    } else {
      setSelectedServices(new Set());
    }
  };

  const handleSelectService = (id) => {
    const newSet = new Set(selectedServices);
    if (newSet.has(id)) {
      newSet.delete(id);
    } else {
      newSet.add(id);
    }
    setSelectedServices(newSet);
  };

  const handleBulkEdit = async () => {
    if (selectedServices.size === 0) return;

    setLoading(true);
    try {
      await base44.functions.invoke('bulkEditServices', {
        service_ids: Array.from(selectedServices),
        updates: bulkEditData
      });
      setShowBulkEdit(false);
      setBulkEditData({});
      setSelectedServices(new Set());
      onRefresh();
    } finally {
      setLoading(false);
    }
  };

  const handleEditAllCommission = async () => {
    setLoading(true);
    try {
      const allServiceIds = services.map(s => s.id);
      await base44.functions.invoke('bulkEditServices', {
        service_ids: allServiceIds,
        updates: { commission_percentage: globalCommission }
      });
      setShowEditAllCommission(false);
      onRefresh();
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-4">
      {/* Filters */}
      <div className="grid grid-cols-1 md:grid-cols-5 gap-3">
        <div className="relative">
          <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
          <Input
            placeholder="Search services..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="pl-8"
          />
        </div>

        <Select value={selectedBrand} onValueChange={setSelectedBrand}>
          <SelectTrigger>
            <SelectValue placeholder="Brand" />
          </SelectTrigger>
          <SelectContent>
            {BRANDS.map(brand => (
              <SelectItem key={brand} value={brand}>{brand}</SelectItem>
            ))}
          </SelectContent>
        </Select>

        <Select value={selectedCategory} onValueChange={setSelectedCategory}>
          <SelectTrigger>
            <SelectValue placeholder="Category" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value={null}>All Categories</SelectItem>
            {CATEGORIES.map(cat => (
              <SelectItem key={cat} value={cat}>{cat}</SelectItem>
            ))}
          </SelectContent>
        </Select>

        <div className="flex gap-2">
          <Input
            type="number"
            placeholder="Min"
            value={priceRange.min}
            onChange={(e) => setPriceRange({ ...priceRange, min: parseFloat(e.target.value) || 0 })}
            className="w-20"
          />
          <Input
            type="number"
            placeholder="Max"
            value={priceRange.max}
            onChange={(e) => setPriceRange({ ...priceRange, max: parseFloat(e.target.value) || 10 })}
            className="w-20"
          />
        </div>

        {selectedServices.size > 0 && (
          <Button
            variant="outline"
            size="sm"
            onClick={() => setShowBulkEdit(!showBulkEdit)}
            className="w-full"
          >
            Edit {selectedServices.size} items
          </Button>
        )}

        <Button
          variant="outline"
          size="sm"
          onClick={() => setShowEditAllCommission(true)}
          className="w-full gap-1"
        >
          <Percent className="w-3.5 h-3.5" />
          Edit All Commission
        </Button>
      </div>

      {/* Bulk Edit Panel */}
      {showBulkEdit && selectedServices.size > 0 && (
        <div className="border border-border rounded-lg p-4 bg-card space-y-3">
          <h3 className="font-semibold">Bulk Edit {selectedServices.size} Services</h3>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
            <div>
              <label className="text-xs text-muted-foreground">Commission %</label>
              <Input
                type="number"
                placeholder="50"
                value={bulkEditData.commission_percentage || ''}
                onChange={(e) => setBulkEditData({ ...bulkEditData, commission_percentage: parseFloat(e.target.value) })}
              />
            </div>

            <div>
              <label className="text-xs text-muted-foreground">Category</label>
              <Select
                value={bulkEditData.category || ''}
                onValueChange={(val) => setBulkEditData({ ...bulkEditData, category: val })}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Category" />
                </SelectTrigger>
                <SelectContent>
                  {CATEGORIES.map(cat => (
                    <SelectItem key={cat} value={cat}>{cat}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div>
              <label className="text-xs text-muted-foreground">Price Override</label>
              <Input
                type="number"
                placeholder="Auto"
                step="0.01"
                value={bulkEditData.price || ''}
                onChange={(e) => setBulkEditData({ ...bulkEditData, price: parseFloat(e.target.value) })}
              />
            </div>

            <div className="flex items-end gap-2">
              <Button
                size="sm"
                variant="outline"
                onClick={() => setBulkEditData({ ...bulkEditData, is_active: !bulkEditData.is_active })}
                className="flex-1"
              >
                {bulkEditData.is_active === true ? 'Active' : bulkEditData.is_active === false ? 'Inactive' : 'Toggle'}
              </Button>
            </div>
          </div>

          <div className="flex gap-2">
            <Button size="sm" onClick={handleBulkEdit} disabled={loading || Object.keys(bulkEditData).length === 0}>
              {loading ? 'Applying...' : 'Apply Changes'}
            </Button>
            <Button size="sm" variant="ghost" onClick={() => { setShowBulkEdit(false); setBulkEditData({}); }}>
              Cancel
            </Button>
          </div>
        </div>
      )}

      {/* Table - Desktop */}
      <div className="hidden md:block border border-border rounded-lg overflow-hidden">
        <table className="w-full text-sm">
          <thead className="bg-card/50 border-b border-border">
            <tr>
              <th className="px-4 py-2 text-left w-8">
                <Checkbox
                  checked={selectedServices.size > 0 && selectedServices.size === filteredServices.length}
                  onCheckedChange={handleSelectAll}
                />
              </th>
              <th className="px-4 py-2 text-left">Service Name</th>
              <th className="px-4 py-2 text-left">Brand</th>
              <th className="px-4 py-2 text-left">Category</th>
              <th className="px-4 py-2 text-right">API Cost</th>
              <th className="px-4 py-2 text-right">Commission %</th>
              <th className="px-4 py-2 text-right">Retail Price</th>
              <th className="px-4 py-2 text-center">Status</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-border">
            {filteredServices.map((service) => (
              <tr key={service.id} className="hover:bg-card/50 transition-colors">
                <td className="px-4 py-2">
                  <Checkbox
                    checked={selectedServices.has(service.id)}
                    onCheckedChange={() => handleSelectService(service.id)}
                  />
                </td>
                <td className="px-4 py-2 font-medium">{service.service_name}</td>
                <td className="px-4 py-2">{service.brand || 'All Brands'}</td>
                <td className="px-4 py-2">
                  <Badge variant="outline" className="text-xs">{service.category || 'Other'}</Badge>
                </td>
                <td className="px-4 py-2 text-right">${(service.api_cost ?? 0).toFixed(2)}</td>
                <td className="px-4 py-2 text-right">{service.commission_percentage ?? 50}%</td>
                <td className="px-4 py-2 text-right font-semibold text-primary">${(service.price ?? 0).toFixed(2)}</td>
                <td className="px-4 py-2 text-center">
                  <Badge variant={service.is_active ? "default" : "secondary"}>
                    {service.is_active ? 'Active' : 'Inactive'}
                  </Badge>
                </td>
              </tr>
            ))}
          </tbody>
        </table>

        {filteredServices.length === 0 && (
          <div className="px-4 py-8 text-center text-muted-foreground">
            No services found
          </div>
        )}
      </div>

      {/* Mobile Card View */}
      <div className="md:hidden space-y-3">
        {filteredServices.map((service) => (
          <div key={service.id} className="border border-border rounded-lg p-3 space-y-2">
            <div className="flex items-start gap-3">
              <Checkbox
                checked={selectedServices.has(service.id)}
                onCheckedChange={() => handleSelectService(service.id)}
              />
              <div className="flex-1">
                <p className="font-medium text-foreground">{service.service_name}</p>
                <p className="text-xs text-muted-foreground">{service.brand || 'All Brands'}</p>
              </div>
            </div>
            <div className="flex gap-2 flex-wrap pl-8">
              <Badge variant="outline" className="text-xs">{service.category || 'Other'}</Badge>
              <Badge variant={service.is_active ? "default" : "secondary"} className="text-xs">
                {service.is_active ? 'Active' : 'Inactive'}
              </Badge>
            </div>
            <div className="grid grid-cols-3 gap-2 pl-8 text-xs pt-1">
              <div>
                <p className="text-muted-foreground">API Cost</p>
                <p className="font-medium text-foreground">${(service.api_cost ?? 0).toFixed(2)}</p>
              </div>
              <div>
                <p className="text-muted-foreground">Commission</p>
                <p className="font-medium text-foreground">{service.commission_percentage ?? 50}%</p>
              </div>
              <div>
                <p className="text-muted-foreground">Price</p>
                <p className="font-medium text-primary">${(service.price ?? 0).toFixed(2)}</p>
              </div>
            </div>
          </div>
        ))}
        
        {filteredServices.length === 0 && (
          <div className="text-center py-8 text-muted-foreground">
            No services found
          </div>
        )}
      </div>

      <div className="text-xs text-muted-foreground">
        Showing {filteredServices.length} of {services.length} services
      </div>

      {/* Edit All Commission Dialog */}
      <AlertDialog open={showEditAllCommission} onOpenChange={setShowEditAllCommission}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Edit Commission for All Services</AlertDialogTitle>
            <AlertDialogDescription>
              This will update the commission percentage for all {services.length} services.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <div className="space-y-3">
            <div>
              <label className="text-sm font-medium text-foreground">Commission Percentage</label>
              <Input
                type="number"
                value={globalCommission}
                onChange={(e) => setGlobalCommission(parseFloat(e.target.value) || 0)}
                className="mt-1"
              />
            </div>
          </div>
          <div className="flex gap-2 justify-end">
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction
              onClick={handleEditAllCommission}
              disabled={loading}
              className="gradient-btn text-white border-0"
            >
              {loading ? 'Updating...' : 'Update All'}
            </AlertDialogAction>
          </div>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}