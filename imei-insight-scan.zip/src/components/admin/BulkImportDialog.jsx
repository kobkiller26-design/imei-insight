import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { Button } from '@/components/ui/button';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from '@/components/ui/dialog';
import { Textarea } from '@/components/ui/textarea';
import { AlertCircle, CheckCircle2 } from 'lucide-react';

export default function BulkImportDialog({ open, onOpenChange, onSuccess }) {
  const [content, setContent] = useState('');
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState(null);

  const parseServices = (text) => {
    const lines = text.trim().split('\n').filter(line => line.trim());
    const services = [];

    for (const line of lines) {
      const parts = line.split('|').map(p => p.trim());
      if (parts.length >= 3) {
        const [service_name, brand, api_cost] = parts;
        services.push({
          service_name,
          service_id: `${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
          api_cost: parseFloat(api_cost)
        });
      }
    }
    return services;
  };

  const handleImport = async () => {
    if (!content.trim()) return;

    setLoading(true);
    try {
      const services = parseServices(content);
      const response = await base44.functions.invoke('bulkImportServices', { services });
      setResult(response.data);
      if (response.data.success) {
        setTimeout(() => {
          setContent('');
          setResult(null);
          onOpenChange(false);
          onSuccess?.();
        }, 2000);
      }
    } finally {
      setLoading(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-2xl">
        <DialogHeader>
          <DialogTitle>Bulk Import Services</DialogTitle>
          <DialogDescription>
            Paste services in format: Service Name | Brand | API Cost (one per line)
          </DialogDescription>
        </DialogHeader>

        {!result ? (
          <div className="space-y-3">
            <Textarea
              placeholder="Apple FULL INFO [+Carrier] A | Apple | 0.05
Samsung Info (S1) (IMEI) | Samsung | 0.06
Blacklist Pro Check | All Brands | 0.03"
              value={content}
              onChange={(e) => setContent(e.target.value)}
              className="h-40 font-mono text-xs"
            />
            <div className="text-xs text-muted-foreground">
              Format: Service Name | Brand | API Cost (one per line)
            </div>
            <div className="flex gap-2">
              <Button onClick={handleImport} disabled={loading || !content.trim()}>
                {loading ? 'Importing...' : 'Import Services'}
              </Button>
              <Button variant="ghost" onClick={() => onOpenChange(false)}>
                Cancel
              </Button>
            </div>
          </div>
        ) : (
          <div className="space-y-3">
            <div className={`flex items-start gap-3 p-3 rounded-lg ${result.success ? 'bg-green-500/10' : 'bg-red-500/10'}`}>
              {result.success ? (
                <CheckCircle2 className="w-5 h-5 text-green-600 flex-shrink-0 mt-0.5" />
              ) : (
                <AlertCircle className="w-5 h-5 text-red-600 flex-shrink-0 mt-0.5" />
              )}
              <div className="text-sm">
                <p className="font-semibold">{result.message}</p>
                {result.errors && result.errors.length > 0 && (
                  <div className="mt-2 space-y-1">
                    {result.errors.slice(0, 5).map((err, i) => (
                      <p key={i} className="text-xs text-muted-foreground">• {err}</p>
                    ))}
                  </div>
                )}
              </div>
            </div>
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
}