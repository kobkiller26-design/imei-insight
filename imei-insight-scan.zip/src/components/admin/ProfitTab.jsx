import React, { useMemo } from "react";
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, LineChart, Line, CartesianGrid, Legend } from "recharts";
import { DollarSign, TrendingUp, TrendingDown, Percent, Download } from "lucide-react";
import { Button } from "@/components/ui/button";
import { format, subDays, startOfDay } from "date-fns";

export default function ProfitTab({ checks, purchases }) {
  const completedPurchases = purchases.filter(p => p.status === "completed");
  const successChecks = checks.filter(c => c.status === "success");

  const totalRevenue = completedPurchases.reduce((s, p) => s + (p.amount_paid || 0), 0);
  const totalApiCost = successChecks.reduce((s, c) => s + (c.api_cost || 0), 0);
  const totalProfit = totalRevenue - totalApiCost;
  const profitMargin = totalRevenue > 0 ? ((totalProfit / totalRevenue) * 100).toFixed(1) : 0;

  // Daily data for last 14 days
  const dailyData = useMemo(() => {
    const days = Array.from({ length: 14 }, (_, i) => {
      const day = startOfDay(subDays(new Date(), 13 - i));
      return { date: format(day, "MMM d"), revenue: 0, apiCost: 0, profit: 0, checks: 0 };
    });

    completedPurchases.forEach(p => {
      if (!p.created_date) return;
      const label = format(new Date(p.created_date), "MMM d");
      const d = days.find(d => d.date === label);
      if (d) d.revenue += p.amount_paid || 0;
    });

    successChecks.forEach(c => {
      if (!c.created_date) return;
      const label = format(new Date(c.created_date), "MMM d");
      const d = days.find(d => d.date === label);
      if (d) {
        d.apiCost += c.api_cost || 0;
        d.profit = d.revenue - d.apiCost;
        d.checks += 1;
      }
    });

    return days.map(d => ({
      ...d,
      revenue: parseFloat(d.revenue.toFixed(2)),
      apiCost: parseFloat(d.apiCost.toFixed(2)),
      profit: parseFloat((d.revenue - d.apiCost).toFixed(2))
    }));
  }, [checks, purchases]);

  // Per-service analytics
  const serviceStats = useMemo(() => {
    const map = {};
    successChecks.forEach(c => {
      const key = c.service_name || c.service_id || "Unknown";
      if (!map[key]) map[key] = { name: key, checks: 0, revenue: 0, apiCost: 0, profit: 0 };
      map[key].checks += 1;
      map[key].revenue += c.revenue || 0;
      map[key].apiCost += c.api_cost || 0;
      map[key].profit += (c.revenue || 0) - (c.api_cost || 0);
    });
    return Object.values(map).sort((a, b) => b.profit - a.profit);
  }, [checks]);

  const exportCSV = () => {
    const rows = [
      ["Date", "Revenue ($)", "API Cost ($)", "Profit ($)", "Checks"],
      ...dailyData.map(d => [d.date, d.revenue, d.apiCost, d.profit, d.checks])
    ];
    const csv = rows.map(r => r.join(",")).join("\n");
    const blob = new Blob([csv], { type: "text/csv" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `imei-insight-report-${format(new Date(), "yyyy-MM-dd")}.csv`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const exportServiceCSV = () => {
    const rows = [
      ["Service", "Checks Sold", "Revenue ($)", "API Cost ($)", "Profit ($)"],
      ...serviceStats.map(s => [s.name, s.checks, s.revenue.toFixed(2), s.apiCost.toFixed(2), s.profit.toFixed(2)])
    ];
    const csv = rows.map(r => r.join(",")).join("\n");
    const blob = new Blob([csv], { type: "text/csv" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `imei-service-report-${format(new Date(), "yyyy-MM-dd")}.csv`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const statCards = [
    { label: "Total Revenue", value: `$${totalRevenue.toFixed(2)}`, icon: DollarSign, color: "text-emerald-600 bg-emerald-50", sub: "From credit purchases" },
    { label: "Total API Cost", value: `$${totalApiCost.toFixed(2)}`, icon: TrendingDown, color: "text-red-500 bg-red-50", sub: "Paid to API provider" },
    { label: "Total Profit", value: `$${totalProfit.toFixed(2)}`, icon: TrendingUp, color: "text-indigo-600 bg-indigo-50", sub: "Revenue minus API cost" },
    { label: "Profit Margin", value: `${profitMargin}%`, icon: Percent, color: "text-purple-600 bg-purple-50", sub: "Net margin" }
  ];

  return (
    <div className="space-y-6">
      {/* Summary cards */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        {statCards.map(({ label, value, icon: Icon, color, sub }) => (
          <div key={label} className="bg-card rounded-2xl border border-border p-4 card-shadow">
            <div className={`w-9 h-9 rounded-xl flex items-center justify-center mb-2 ${color}`}>
              <Icon className="w-4 h-4" />
            </div>
            <p className="text-2xl font-bold text-foreground">{value}</p>
            <p className="text-xs font-medium text-foreground mt-0.5">{label}</p>
            <p className="text-xs text-muted-foreground">{sub}</p>
          </div>
        ))}
      </div>

      {/* Revenue & Profit chart */}
      <div className="bg-card rounded-2xl border border-border p-5 card-shadow">
        <div className="flex items-center justify-between mb-4">
          <h3 className="font-semibold text-foreground">Daily Revenue & Profit (14 days)</h3>
          <Button size="sm" variant="outline" onClick={exportCSV}>
            <Download className="w-3.5 h-3.5 mr-1.5" /> Export CSV
          </Button>
        </div>
        <ResponsiveContainer width="100%" height={220}>
          <LineChart data={dailyData}>
            <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
            <XAxis dataKey="date" tick={{ fontSize: 11 }} />
            <YAxis tick={{ fontSize: 11 }} tickFormatter={v => `$${v}`} />
            <Tooltip formatter={v => [`$${v}`, ""]} />
            <Legend />
            <Line type="monotone" dataKey="revenue" stroke="#10b981" strokeWidth={2} dot={false} name="Revenue" />
            <Line type="monotone" dataKey="profit" stroke="#6366f1" strokeWidth={2} dot={false} name="Profit" />
            <Line type="monotone" dataKey="apiCost" stroke="#f87171" strokeWidth={2} dot={false} name="API Cost" />
          </LineChart>
        </ResponsiveContainer>
      </div>

      {/* Daily checks chart */}
      <div className="bg-card rounded-2xl border border-border p-5 card-shadow">
        <h3 className="font-semibold text-foreground mb-4">Daily Checks (14 days)</h3>
        <ResponsiveContainer width="100%" height={180}>
          <BarChart data={dailyData}>
            <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
            <XAxis dataKey="date" tick={{ fontSize: 11 }} />
            <YAxis tick={{ fontSize: 11 }} />
            <Tooltip />
            <Bar dataKey="checks" fill="#6366f1" radius={[4, 4, 0, 0]} name="Checks" />
          </BarChart>
        </ResponsiveContainer>
      </div>

      {/* Per-service analytics */}
      <div className="bg-card rounded-2xl border border-border p-5 card-shadow">
        <div className="flex items-center justify-between mb-4">
          <h3 className="font-semibold text-foreground">Per-Service Analytics</h3>
          <Button size="sm" variant="outline" onClick={exportServiceCSV}>
            <Download className="w-3.5 h-3.5 mr-1.5" /> Export CSV
          </Button>
        </div>
        {serviceStats.length === 0 ? (
          <p className="text-sm text-muted-foreground text-center py-8">No check data yet.</p>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-border">
                  <th className="text-left py-2 text-xs font-semibold text-muted-foreground">Service</th>
                  <th className="text-right py-2 text-xs font-semibold text-muted-foreground">Checks</th>
                  <th className="text-right py-2 text-xs font-semibold text-muted-foreground">Revenue</th>
                  <th className="text-right py-2 text-xs font-semibold text-muted-foreground">API Cost</th>
                  <th className="text-right py-2 text-xs font-semibold text-muted-foreground">Profit</th>
                </tr>
              </thead>
              <tbody>
                {serviceStats.map(s => (
                  <tr key={s.name} className="border-b border-border last:border-0 hover:bg-muted/30">
                    <td className="py-2.5 font-medium text-foreground">{s.name}</td>
                    <td className="py-2.5 text-right text-foreground">{s.checks}</td>
                    <td className="py-2.5 text-right text-emerald-600 font-medium">${s.revenue.toFixed(2)}</td>
                    <td className="py-2.5 text-right text-red-500">${s.apiCost.toFixed(2)}</td>
                    <td className="py-2.5 text-right text-indigo-600 font-semibold">${s.profit.toFixed(2)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
}