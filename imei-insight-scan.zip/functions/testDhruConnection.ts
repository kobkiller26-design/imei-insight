import { createClientFromRequest } from 'npm:@base44/sdk@0.8.20';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();

    if (user?.role !== 'admin') {
      return Response.json({ error: 'Forbidden' }, { status: 403 });
    }

    const apiKey = Deno.env.get('DHRU_API_KEY');
    
    if (!apiKey) {
      return Response.json({ error: 'Missing DHRU_API_KEY' }, { status: 400 });
    }

    // Test different action/request parameters
    const endpoint = 'https://dhru.checkimei.com/api/index.php';
    const testParams = [
      { action: 'services' },
      { request: 'services' },
      { action: 'getServices' },
      { action: 'get_services' },
      { request: 'getServices' },
    ];

    const results = [];

    for (const params of testParams) {
      try {
        console.log('Testing params:', params);
        
        const body = new URLSearchParams({
          username: 'WilnoEsteril565',
          apiaccesskey: apiKey,
          ...params
        });

        const response = await fetch(endpoint, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/x-www-form-urlencoded'
          },
          body: body.toString()
        });

        const text = await response.text();
        console.log('Response (first 200 chars):', text.substring(0, 200));

        let data = null;
        try {
          data = JSON.parse(text);
        } catch (e) {
          console.log('Parse error for params:', params);
        }

        results.push({
          params,
          status: response.status,
          isJson: !!data,
          data: data || { raw: text.substring(0, 150) }
        });

        // Stop if we get valid JSON with services
        if (data && !data.ERROR) {
          console.log('Found working params!');
          break;
        }
      } catch (err) {
        console.error('Error:', err.message);
        results.push({ params, error: err.message });
      }
    }

    return Response.json({ results });

  } catch (error) {
    console.error('Error:', error);
    return Response.json({ error: error.message }, { status: 500 });
  }
});