import { createClientFromRequest } from 'npm:@base44/sdk@0.8.20';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();

    if (!user) {
      return Response.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const body = await req.json();
    const { imeiCheckId } = body;

    if (!imeiCheckId) {
      return Response.json({ error: 'imeiCheckId is required' }, { status: 400 });
    }

    const apiKey = Deno.env.get('IMEI_API_KEY');
    if (!apiKey) {
      return Response.json({ error: 'IMEI_API_KEY not configured' }, { status: 500 });
    }

    // Get the IMEI check record
    const records = await base44.entities.ImeiCheck.filter({ id: imeiCheckId });
    
    if (!records || records.length === 0) {
      return Response.json({ error: 'IMEI check not found' }, { status: 404 });
    }

    const record = records[0];

    // Only check status for pending records
    if (record.status !== 'pending') {
      return Response.json({ 
        message: 'Record already has final status',
        status: record.status 
      });
    }

    // Call the history endpoint
    const historyUrl = new URL('https://alpha.imeicheck.com/api/php-api/history');
    historyUrl.searchParams.set('key', apiKey);
    historyUrl.searchParams.set('orderId', record.id);

    console.log(`Checking status for order: ${record.id}`);

    const apiResponse = await fetch(historyUrl.toString(), {
      method: 'GET',
      headers: {
        'Accept': 'application/json'
      }
    });

    if (!apiResponse.ok) {
      const errorText = await apiResponse.text();
      console.error(`API Error ${apiResponse.status}: ${errorText}`);
      return Response.json({ 
        error: `Failed to check status: ${apiResponse.status}`
      }, { status: apiResponse.status });
    }

    const result = await apiResponse.json();
    console.log('History response:', result);

    // Save the full JSON response
    const updateData = {
      result_json: JSON.stringify(result)
    };

    // Parse and update fields if result is complete
    if (result.status === 'success' || result.status === 'completed') {
      updateData.status = 'success';
      
      if (result.device_name) updateData.device_name = result.device_name;
      if (result.brand) updateData.brand = result.brand;
      if (result.model) updateData.model = result.model;
      if (result.carrier) updateData.carrier = result.carrier;
      if (result.country) updateData.country = result.country;
      if (result.blacklist_status) updateData.blacklist_status = result.blacklist_status;
      if (result.sim_lock) updateData.sim_lock = result.sim_lock;
      if (result.warranty_status) updateData.warranty_status = result.warranty_status;
      if (result.network_type) updateData.network_type = result.network_type;
    } else if (result.status === 'error' || result.status === 'failed') {
      updateData.status = 'error';
      updateData.error_message = result.error || result.message || 'API returned error status';
    } else if (result.status === 'pending') {
      return Response.json({
        message: 'Order still processing',
        status: 'pending'
      });
    }

    // Update the record
    await base44.entities.ImeiCheck.update(imeiCheckId, updateData);

    return Response.json({
      success: true,
      status: updateData.status,
      message: `Updated to ${updateData.status}`
    });

  } catch (error) {
    console.error('Status check error:', error);
    return Response.json({ error: error.message }, { status: 500 });
  }
});