import { createClientFromRequest } from 'npm:@base44/sdk@0.8.20';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();

    if (user?.role !== 'admin') {
      return Response.json({ error: 'Forbidden' }, { status: 403 });
    }

    const apiKey = Deno.env.get('DHRU_API_KEY');
    if (!apiKey) {
      return Response.json({ error: 'Missing API key' }, { status: 400 });
    }

    // Test different auth formats
    const tests = [
      {
        name: 'Query param: api_key',
        url: `https://dhru.checkimei.com/api/index.php?action=getServices&api_key=${apiKey}`,
      },
      {
        name: 'Query param: key',
        url: `https://dhru.checkimei.com/api/index.php?action=getServices&key=${apiKey}`,
      },
      {
        name: 'Query param: token',
        url: `https://dhru.checkimei.com/api/index.php?action=getServices&token=${apiKey}`,
      },
      {
        name: 'Header: Authorization Bearer',
        url: `https://dhru.checkimei.com/api/index.php?action=getServices`,
        headers: { 'Authorization': `Bearer ${apiKey}` },
      },
      {
        name: 'Header: X-API-Key',
        url: `https://dhru.checkimei.com/api/index.php?action=getServices`,
        headers: { 'X-API-Key': apiKey },
      },
    ];

    const results = [];

    for (const test of tests) {
      try {
        const response = await fetch(test.url, {
          method: 'GET',
          headers: test.headers || {},
        });
        const text = await response.text();
        
        let data = null;
        try {
          data = JSON.parse(text);
        } catch {}

        results.push({
          name: test.name,
          success: !data?.ERROR,
          response: data || text.substring(0, 100),
        });
      } catch (err) {
        results.push({
          name: test.name,
          error: err.message,
        });
      }
    }

    return Response.json({ results });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});