import { createClientFromRequest } from 'npm:@base44/sdk@0.8.20';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();

    if (user?.role !== 'admin') {
      return Response.json({ error: 'Forbidden: Admin access required' }, { status: 403 });
    }

    const apiKey = Deno.env.get('DHRU_API_KEY');
    if (!apiKey) {
      return Response.json({ error: 'DHRU_API_KEY not configured' }, { status: 400 });
    }

    const endpoints = [
      'https://dhru.checkimei.com/api/index.php',
      'https://dhru.checkimei.com/dhru/api/index.php',
      'https://dhru.checkimei.com/api.php',
      'https://dhru.checkimei.com/api/',
    ];

    let workingEndpoint = null;
    let testResults = [];

    for (const endpoint of endpoints) {
      try {
        const url = new URL(endpoint);
        url.searchParams.append('action', 'getServices');
        url.searchParams.append('api_key', apiKey);

        const response = await fetch(url.toString(), {
          method: 'GET',
          timeout: 10000,
        });

        const text = await response.text();
        let data;
        try {
          data = JSON.parse(text);
        } catch {
          data = null;
        }

        // Check if response indicates success (status 200, has content, and is valid JSON or has data)
        if (response.ok && text.length > 0 && data) {
          workingEndpoint = endpoint;
          testResults.push({
            endpoint,
            status: 'success',
            statusCode: response.status,
            serviceCount: Array.isArray(data) ? data.length : (data.data ? data.data.length : Object.keys(data).length),
          });
          break;
        } else {
          testResults.push({
            endpoint,
            status: 'failed',
            statusCode: response.status,
            reason: data?.error || response.statusText || 'Invalid response format',
            responseLength: text.length,
          });
        }
      } catch (err) {
        testResults.push({
          endpoint,
          status: 'error',
          error: err.message,
        });
      }
    }

    if (!workingEndpoint) {
      return Response.json({
        success: false,
        error: 'No working endpoint found',
        testResults,
      }, { status: 400 });
    }

    return Response.json({
      success: true,
      workingEndpoint,
      testResults,
    });
  } catch (error) {
    console.error('Endpoint detection error:', error);
    return Response.json({ error: error.message }, { status: 500 });
  }
});