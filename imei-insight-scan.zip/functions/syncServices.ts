import { createClientFromRequest } from 'npm:@base44/sdk@0.8.20';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();

    // Admin only
    if (user?.role !== 'admin') {
      return Response.json({ error: 'Forbidden: Admin access required' }, { status: 403 });
    }

    // imeicheck.com does not provide a public services list endpoint
    // Return helpful message directing users to add services manually
    return Response.json({ 
      error: 'Service sync not available',
      message: 'imeicheck.com API does not provide a services list endpoint. Use the "Add Service" form to create services manually.',
      hint: 'Get service IDs from your imeicheck.com dashboard'
    }, { status: 501 });

  } catch (error) {
    console.error('Sync error:', error);
    return Response.json({ error: error.message }, { status: 500 });
  }
});