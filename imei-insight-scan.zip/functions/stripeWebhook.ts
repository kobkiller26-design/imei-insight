import { createClientFromRequest } from 'npm:@base44/sdk@0.8.20';
import Stripe from 'npm:stripe@14.21.0';

const CREDITS_MAP = {
  'price_1T8GEVBKoCShLu5sQREbBJPi': 10,   // Starter $5
  'price_1T8GEVBKoCShLu5sbd2dvWlw': 50,   // Pro $15
  'price_1T8GEVBKoCShLu5slFSAK5hA': 200,  // Business $40
};

Deno.serve(async (req) => {
  const stripe = new Stripe(Deno.env.get('STRIPE_SECRET_KEY'));
  const webhookSecret = Deno.env.get('STRIPE_WEBHOOK_SECRET');

  const body = await req.text();
  const signature = req.headers.get('stripe-signature');

  let event;
  try {
    event = await stripe.webhooks.constructEventAsync(body, signature, webhookSecret);
  } catch (err) {
    console.error('Webhook signature verification failed:', err.message);
    return Response.json({ error: 'Invalid signature' }, { status: 400 });
  }

  if (event.type === 'checkout.session.completed') {
    const session = event.data.object;
    const userId = session.metadata?.user_id;
    const priceId = session.metadata?.price_id;

    console.log('Checkout completed:', { userId, priceId, sessionId: session.id });

    if (!userId || !priceId) {
      console.error('Missing metadata:', { userId, priceId });
      return Response.json({ error: 'Missing metadata' }, { status: 400 });
    }

    const creditsToAdd = CREDITS_MAP[priceId];
    if (!creditsToAdd) {
      console.error('Unknown price ID:', priceId);
      return Response.json({ error: 'Unknown price' }, { status: 400 });
    }

    try {
      const base44 = createClientFromRequest(req);

      // Get current user credits
      const users = await base44.asServiceRole.entities.User.filter({ id: userId });
      const user = users[0];
      const currentCredits = user?.credits || 0;
      const newCredits = currentCredits + creditsToAdd;

      await base44.asServiceRole.entities.User.update(userId, { credits: newCredits });

      // Record the payment
      await base44.asServiceRole.entities.CreditPurchase.create({
        user_id: userId,
        stripe_session_id: session.id,
        price_id: priceId,
        credits_added: creditsToAdd,
        amount_paid: session.amount_total / 100,
        status: 'completed'
      });

      console.log(`Added ${creditsToAdd} credits to user ${userId}. New total: ${newCredits}`);
    } catch (err) {
      console.error('Failed to update credits:', err.message);
      return Response.json({ error: 'Failed to update credits' }, { status: 500 });
    }
  }

  return Response.json({ received: true });
});