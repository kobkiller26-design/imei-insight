import { createClientFromRequest } from 'npm:@base44/sdk@0.8.20';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();

    // Admin only
    if (user?.role !== 'admin') {
      return Response.json({ error: 'Forbidden: Admin access required' }, { status: 403 });
    }

    const apiKey = Deno.env.get('IMEI_API_KEY');
    if (!apiKey) {
      return Response.json({ 
        error: 'IMEI_API_KEY not configured',
        hint: 'Add IMEI_API_KEY in Dashboard > Settings > Environment Variables'
      }, { status: 500 });
    }

    // Fetch services list from imeicheck.com API
    // The API uses different endpoints - try the list endpoint
    const url = new URL('https://alpha.imeicheck.com/api/php-api/list');
    url.searchParams.set('key', apiKey);

    console.log('Fetching services from imeicheck.com API...');
    console.log('URL:', url.toString());

    const response = await fetch(url.toString(), {
      method: 'GET',
      headers: { 'Accept': 'application/json' }
    });

    const contentType = response.headers.get('content-type');
    console.log('Response status:', response.status, 'Content-Type:', contentType);

    const responseText = await response.text();
    console.log('Raw response (first 500 chars):', responseText.substring(0, 500));

    if (!response.ok) {
      console.error('API error response:', responseText);
      return Response.json({ 
        error: `API error: ${response.status}`,
        details: responseText.substring(0, 200)
      }, { status: response.status });
    }

    let data;
    try {
      data = JSON.parse(responseText);
    } catch (e) {
      console.error('Failed to parse JSON:', e.message);
      return Response.json({ 
        error: 'API returned invalid JSON',
        details: 'The endpoint might not be correct or API key might be invalid'
      }, { status: 400 });
    }
    console.log('Services data received:', JSON.stringify(data).substring(0, 200) + '...');

    // Parse services - the API returns an object with service IDs as keys
    const servicesArray = [];
    if (data && typeof data === 'object') {
      for (const [serviceId, serviceData] of Object.entries(data)) {
        if (serviceData && typeof serviceData === 'object') {
          servicesArray.push({
            service_id: String(serviceId),
            service_name: serviceData.name || serviceData.service_name || `Service ${serviceId}`,
            api_cost: parseFloat(serviceData.price) || parseFloat(serviceData.cost) || 0,
            brand: serviceData.brand || serviceData.manufacturer || 'All Brands',
            category: serviceData.category || 'Other',
            description: serviceData.description || '',
            is_active: true,
            commission_percentage: 50
          });
        }
      }
    }

    console.log(`Parsed ${servicesArray.length} services`);

    if (servicesArray.length === 0) {
      return Response.json({ 
        error: 'No services found in API response',
        hint: 'Check your API key and imeicheck.com account'
      }, { status: 400 });
    }

    // Get existing services
    const existingServices = await base44.asServiceRole.entities.Service.list();
    const existingIds = new Set(existingServices.map(s => s.service_id));

    // Separate new and existing services
    const newServices = servicesArray.filter(s => !existingIds.has(s.service_id));
    const toUpdate = servicesArray.filter(s => existingIds.has(s.service_id));

    console.log(`Found ${newServices.length} new services, ${toUpdate.length} to update`);

    // Create new services
    let createdCount = 0;
    if (newServices.length > 0) {
      try {
        await base44.asServiceRole.entities.Service.bulkCreate(newServices);
        createdCount = newServices.length;
        console.log(`Created ${createdCount} new services`);
      } catch (e) {
        console.error('Error creating services:', e.message);
      }
    }

    // Update existing services (sync prices)
    let updatedCount = 0;
    for (const service of toUpdate) {
      try {
        const existing = existingServices.find(s => s.service_id === service.service_id);
        if (existing) {
          // Calculate new price with current commission
          const commission = existing.commission_percentage || 50;
          const newPrice = service.api_cost * (1 + commission / 100);
          
          await base44.asServiceRole.entities.Service.update(existing.id, {
            api_cost: service.api_cost,
            price: newPrice,
            service_name: service.service_name,
            brand: service.brand,
            category: service.category,
            description: service.description
          });
          updatedCount++;
        }
      } catch (e) {
        console.error(`Error updating service ${service.service_id}:`, e.message);
      }
    }

    console.log(`Updated ${updatedCount} existing services`);

    return Response.json({
      success: true,
      message: `Synced ${servicesArray.length} services successfully`,
      created: createdCount,
      updated: updatedCount,
      total: servicesArray.length
    });

  } catch (error) {
    console.error('Fetch services error:', error.message);
    return Response.json({ error: error.message }, { status: 500 });
  }
});