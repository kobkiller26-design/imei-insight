import { createClientFromRequest } from 'npm:@base44/sdk@0.8.20';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();

    if (!user) {
      return Response.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const { imei, service_id, service_name, is_bulk, bulk_id } = await req.json();

    // Validate IMEI
    if (!imei || !/^\d{14,16}$/.test(imei.trim())) {
      return Response.json({ error: 'Invalid IMEI. Must be 14-16 digits.' }, { status: 400 });
    }

    if (!service_id) {
      return Response.json({ error: 'Service ID is required.' }, { status: 400 });
    }

    const apiKey = Deno.env.get('IMEI_API_KEY');

    if (!apiKey) {
      return Response.json({ 
        error: 'Setup Required: IMEI_API_KEY not configured',
        hint: 'Add IMEI_API_KEY in Dashboard > Settings > Environment Variables'
      }, { status: 500 });
    }

    // Check user credits
    const users = await base44.asServiceRole.entities.User.filter({ id: user.id });
    const userRecord = users[0];
    const currentCredits = userRecord?.credits || 0;

    if (currentCredits < 1) {
      return Response.json({ 
        error: 'Insufficient credits. Please purchase more credits to continue.',
        credits_required: true,
        current_credits: 0
      }, { status: 402 });
    }

    // Fetch service to get api_cost and revenue info
    let apiCost = 0;
    let creditValue = 1; // default $1 revenue per credit
    try {
      const services = await base44.asServiceRole.entities.Service.filter({ service_id: String(service_id) });
      if (services[0]) {
        apiCost = services[0].api_cost || 0;
        creditValue = services[0].price || 1;
      }
    } catch (e) {
      console.warn('Could not fetch service pricing:', e.message);
    }

    // Deduct 1 credit immediately
    await base44.asServiceRole.entities.User.update(user.id, { 
      credits: currentCredits - 1 
    });

    // Create a pending record
    const checkRecord = await base44.asServiceRole.entities.ImeiCheck.create({
      user_id: user.id,
      imei: imei.trim(),
      service_id: String(service_id),
      service_name: service_name || '',
      status: 'pending',
      is_bulk: is_bulk || false,
      bulk_id: bulk_id || null,
      api_cost: apiCost,
      revenue: creditValue,
      profit: creditValue - apiCost
    });

    // Call the imeicheck.com API to create order
    const imeiCheckUrl = new URL('https://alpha.imeicheck.com/api/php-api/create');
    imeiCheckUrl.searchParams.set('key', apiKey);
    imeiCheckUrl.searchParams.set('service', service_id);
    imeiCheckUrl.searchParams.set('imei', imei.trim());

    console.log(`Creating IMEI check: ${imei}, service: ${service_id}`);

    const apiResponse = await fetch(imeiCheckUrl.toString(), {
      method: 'GET',
      headers: {
        'Accept': 'application/json'
      }
    });

    const apiData = await apiResponse.json();

    if (!apiResponse.ok) {
      // Refund credit on API failure
      await base44.asServiceRole.entities.User.update(user.id, { credits: currentCredits });
      
      await base44.asServiceRole.entities.ImeiCheck.update(checkRecord.id, {
        status: 'error',
        error_message: apiData.message || apiData.error || `API error: ${apiResponse.status}`,
        result_json: JSON.stringify(apiData),
        api_cost: 0,
        revenue: 0,
        profit: 0
      });

      return Response.json({
        success: false,
        check_id: checkRecord.id,
        error: apiData.message || apiData.error || `API request failed with status ${apiResponse.status}`
      }, { status: apiResponse.status });
    }

    // Extract fields from API response
    const properties = apiData.properties || apiData.result || apiData || {};

    const brand = properties.brand || properties.Brand || properties.manufacturer || '';
    const model = properties.model || properties.Model || properties.modelName || '';
    const device_name = properties.deviceName || properties.device_name || properties.name || properties.fullName || '';
    const carrier = properties.carrier || properties.Carrier || properties.network || properties.operator || '';
    const country = properties.country || properties.Country || properties.countryName || '';
    const blacklist_status = properties.blacklistStatus || properties.blacklist || properties.blacklistState || properties.gsmaStatus || '';
    const sim_lock = properties.simLock || properties.simLockStatus || properties.locked || '';
    const warranty_status = properties.warrantyStatus || properties.warranty || properties.warrantyExpiry || '';
    const network_type = properties.networkType || properties.network_type || properties.technology || properties.networkTechnology || '';
    const imei2 = properties.imei2 || properties.IMEI2 || properties.dual_imei || '';
    const serial_number = properties.serialNumber || properties.serial_number || properties.sn || properties.SNR || '';
    const purchase_date = properties.purchaseDate || properties.purchase_date || properties.activationDate || '';
    const fmi_status = properties.fmiStatus || properties.fmi || properties.findMyiPhone || properties.icloudStatus || '';

    // Update record with results
    await base44.asServiceRole.entities.ImeiCheck.update(checkRecord.id, {
      status: 'success',
      result_json: JSON.stringify(apiData),
      brand,
      model,
      device_name,
      carrier,
      country,
      blacklist_status: String(blacklist_status),
      sim_lock: String(sim_lock),
      warranty_status: String(warranty_status),
      network_type: String(network_type),
      imei2: String(imei2),
      serial_number: String(serial_number),
      purchase_date: String(purchase_date),
      fmi_status: String(fmi_status)
    });

    console.log(`IMEI check success: ${imei}, user: ${user.id}, api_cost: ${apiCost}, revenue: ${creditValue}`);

    return Response.json({
      success: true,
      check_id: checkRecord.id,
      credits_remaining: currentCredits - 1,
      data: {
        imei: imei.trim(),
        brand,
        model,
        device_name,
        carrier,
        country,
        blacklist_status: String(blacklist_status),
        sim_lock: String(sim_lock),
        warranty_status: String(warranty_status),
        network_type: String(network_type),
        imei2: String(imei2),
        serial_number: String(serial_number),
        purchase_date: String(purchase_date),
        fmi_status: String(fmi_status),
        raw: apiData
      }
    });

  } catch (error) {
    console.error('IMEI check error:', error.message);
    return Response.json({ error: error.message }, { status: 500 });
  }
});