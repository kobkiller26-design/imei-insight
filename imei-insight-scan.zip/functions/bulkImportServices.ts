import { createClientFromRequest } from 'npm:@base44/sdk@0.8.20';

const CATEGORY_KEYWORDS = {
  'Apple': ['apple', 'iphone', 'ipad', 'imac', 'macbook', 'airpods'],
  'Samsung': ['samsung', 'galaxy'],
  'Xiaomi': ['xiaomi', 'redmi', 'poco'],
  'Huawei': ['huawei', 'honor'],
  'Motorola': ['motorola', 'moto'],
  'Google Pixel': ['pixel', 'google'],
  'OnePlus': ['oneplus'],
  'Carrier Checks': ['carrier', 'esn', 'min', 'verizon', 'at&t', 't-mobile', 'sprint'],
  'Blacklist Checks': ['blacklist', 'gsma', 'stolen', 'lost'],
  'Warranty / Activation': ['warranty', 'activation', 'retail'],
  'FMI / iCloud': ['fmi', 'icloud', 'find my'],
  'Converters': ['converter', 'imei to', 'sn to', 'convert']
};

function categorizeService(serviceName) {
  const name = serviceName.toLowerCase();
  for (const [category, keywords] of Object.entries(CATEGORY_KEYWORDS)) {
    if (keywords.some(keyword => name.includes(keyword))) {
      return category;
    }
  }
  return 'Other';
}

function extractBrand(serviceName) {
  const name = serviceName.toLowerCase();
  for (const brand of ['Apple', 'Samsung', 'Xiaomi', 'Huawei', 'Motorola', 'Google Pixel', 'OnePlus', 'Honor']) {
    if (name.includes(brand.toLowerCase())) {
      return brand;
    }
  }
  return 'All Brands';
}

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();

    if (user?.role !== 'admin') {
      return Response.json({ error: 'Forbidden: Admin access required' }, { status: 403 });
    }

    const { services } = await req.json();

    if (!Array.isArray(services) || services.length === 0) {
      return Response.json({ error: 'services array required' }, { status: 400 });
    }

    let created = 0;
    let skipped = 0;
    const errors = [];

    // Get existing services to avoid duplicates
    const existing = await base44.asServiceRole.entities.Service.list();
    const existingIds = new Set(existing.map(s => s.service_id));

    for (const service of services) {
      try {
        const { service_name, service_id, api_cost } = service;

        if (!service_name || !service_id || api_cost === undefined) {
          skipped++;
          continue;
        }

        if (existingIds.has(String(service_id))) {
          skipped++;
          continue;
        }

        const category = categorizeService(service_name);
        const brand = extractBrand(service_name);
        const commission = 50;
        const price = parseFloat((api_cost * (1 + commission / 100)).toFixed(4));

        await base44.asServiceRole.entities.Service.create({
          service_name,
          service_id: String(service_id),
          brand,
          category,
          api_cost: parseFloat(api_cost),
          commission_percentage: commission,
          price,
          is_active: true
        });

        created++;
      } catch (e) {
        errors.push(`${service.service_name}: ${e.message}`);
      }
    }

    return Response.json({
      success: true,
      created,
      skipped,
      errors: errors.length > 0 ? errors : null,
      message: `Imported ${created} services, skipped ${skipped}`
    });

  } catch (error) {
    console.error('Bulk import error:', error);
    return Response.json({ error: error.message }, { status: 500 });
  }
});