import { createClientFromRequest } from 'npm:@base44/sdk@0.8.20';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();

    if (user?.role !== 'admin') {
      return Response.json({ error: 'Forbidden: Admin access required' }, { status: 403 });
    }

    const { service_ids, updates } = await req.json();

    if (!Array.isArray(service_ids) || !updates) {
      return Response.json({ error: 'service_ids array and updates object required' }, { status: 400 });
    }

    let updated = 0;
    const errors = [];

    for (const serviceId of service_ids) {
      try {
        const services = await base44.asServiceRole.entities.Service.filter({ id: serviceId });
        
        if (services.length === 0) continue;

        const service = services[0];
        const updateData = { ...updates };

        // Recalculate price if commission changes
        if (updates.commission_percentage !== undefined && !updates.price) {
          updateData.price = parseFloat((service.api_cost * (1 + updates.commission_percentage / 100)).toFixed(4));
        }

        // Allow direct price override
        if (updates.price !== undefined) {
          updateData.price = parseFloat(updates.price);
        }

        await base44.asServiceRole.entities.Service.update(serviceId, updateData);
        updated++;
      } catch (e) {
        errors.push(`Service ${serviceId}: ${e.message}`);
      }
    }

    return Response.json({
      success: true,
      updated,
      errors: errors.length > 0 ? errors : null
    });

  } catch (error) {
    console.error('Bulk edit error:', error);
    return Response.json({ error: error.message }, { status: 500 });
  }
});