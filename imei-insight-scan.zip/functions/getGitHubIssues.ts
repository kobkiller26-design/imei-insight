import { createClientFromRequest } from 'npm:@base44/sdk@0.8.20';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const { owner, repo } = await req.json();

    if (!owner || !repo) {
      return Response.json(
        { error: 'Missing owner or repo parameter' },
        { status: 400 }
      );
    }

    const { accessToken } = await base44.asServiceRole.connectors.getConnection('github');

    const response = await fetch(
      `https://api.github.com/repos/${owner}/${repo}/issues?state=open&per_page=100`,
      {
        headers: {
          'Authorization': `Bearer ${accessToken}`,
          'Accept': 'application/vnd.github.v3+json',
          'User-Agent': 'IMEI-Insight-App'
        }
      }
    );

    if (!response.ok) {
      const error = await response.text();
      return Response.json(
        { error: `GitHub API error: ${response.status}`, details: error },
        { status: response.status }
      );
    }

    const issues = await response.json();

    return Response.json({
      success: true,
      count: issues.length,
      issues: issues.map(issue => ({
        number: issue.number,
        title: issue.title,
        state: issue.state,
        url: issue.html_url,
        created_at: issue.created_at,
        updated_at: issue.updated_at,
        labels: issue.labels.map(l => l.name),
        assignee: issue.assignee?.login || null
      }))
    });
  } catch (error) {
    console.error('Error fetching GitHub issues:', error);
    return Response.json(
      { error: error.message },
      { status: 500 }
    );
  }
});