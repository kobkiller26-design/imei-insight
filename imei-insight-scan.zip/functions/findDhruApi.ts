import { createClientFromRequest } from 'npm:@base44/sdk@0.8.20';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();

    if (user?.role !== 'admin') {
      return Response.json({ error: 'Forbidden' }, { status: 403 });
    }

    const apiKey = Deno.env.get('DHRU_API_KEY');
    if (!apiKey) {
      return Response.json({ error: 'Missing API key' }, { status: 400 });
    }

    // Try different API variations
    const apiVariations = [
      'https://dhru.checkimei.com/api/index.php?action=getServices&api_key=' + apiKey,
      'https://dhru.checkimei.com/api/?action=getServices&api_key=' + apiKey,
      'https://dhru.checkimei.com/api.php?action=getServices&api_key=' + apiKey,
      'https://api.dhru.io/services?api_key=' + apiKey,
      'https://dhru.checkimei.com/api/services?api_key=' + apiKey,
    ];

    const results = [];

    for (const urlStr of apiVariations) {
      try {
        console.log('Testing:', urlStr);
        const response = await fetch(urlStr, { method: 'GET' });
        const text = await response.text();
        
        // Try to parse as JSON
        let data = null;
        let isJson = false;
        try {
          data = JSON.parse(text);
          isJson = true;
        } catch {}

        results.push({
          url: urlStr,
          status: response.status,
          contentType: response.headers.get('content-type'),
          isJson,
          dataType: data ? typeof data : 'unknown',
          isArray: Array.isArray(data),
          preview: text.substring(0, 200),
          length: text.length,
        });
      } catch (err) {
        results.push({
          url: urlStr,
          error: err.message,
        });
      }
    }

    return Response.json({ results });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});