import { createClientFromRequest } from 'npm:@base44/sdk@0.8.20';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();

    if (user?.role !== 'admin') {
      return Response.json({ error: 'Forbidden: Admin access required' }, { status: 403 });
    }

    const { rule_type = 'commission', rules } = await req.json();

    // Get all services
    const services = await base44.asServiceRole.entities.Service.list();
    let updated = 0;

    for (const service of services) {
      let newPrice = service.price;
      let newCommission = service.commission_percentage;

      if (rule_type === 'commission') {
        // Use provided commission for all
        if (rules?.default_commission !== undefined) {
          newCommission = rules.default_commission;
          newPrice = parseFloat((service.api_cost * (1 + newCommission / 100)).toFixed(4));
        }
      } else if (rule_type === 'tiered') {
        // Apply tiered commissions based on api_cost
        const cost = service.api_cost;
        if (cost <= (rules?.cheap_threshold || 0.1)) {
          newCommission = rules?.cheap_commission || 50;
        } else if (cost <= (rules?.medium_threshold || 0.5)) {
          newCommission = rules?.medium_commission || 30;
        } else {
          newCommission = rules?.expensive_commission || 20;
        }
        newPrice = parseFloat((cost * (1 + newCommission / 100)).toFixed(4));
      }

      if (newPrice !== service.price || newCommission !== service.commission_percentage) {
        await base44.asServiceRole.entities.Service.update(service.id, {
          price: newPrice,
          commission_percentage: newCommission
        });
        updated++;
      }
    }

    return Response.json({
      success: true,
      updated,
      total: services.length,
      message: `Recalculated prices for ${updated} services`
    });

  } catch (error) {
    console.error('Recalculate error:', error);
    return Response.json({ error: error.message }, { status: 500 });
  }
});