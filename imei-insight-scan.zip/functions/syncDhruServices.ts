import { createClientFromRequest } from 'npm:@base44/sdk@0.8.20';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();

    // Verify admin access
    if (user?.role !== 'admin') {
      return Response.json({ error: 'Admin access required' }, { status: 403 });
    }

    // Get Dhru API key from secrets
    const dhruApiKey = Deno.env.get('DHRU_API_KEY');
    if (!dhruApiKey) {
      throw new Error('DHRU_API_KEY not configured in environment');
    }

    // Get Dhru API URL (defaults to Dhru's standard endpoint)
    const dhruApiUrl = Deno.env.get('DHRU_API_URL') || 'https://api.dhru.io/api';

    const syncLog = {
      timestamp: new Date().toISOString(),
      provider: 'dhru',
      services_updated: 0,
      services_added: 0,
      services_deactivated: 0,
      errors: null,
      status: 'success'
    };

    // Fetch services from Dhru API using GET with query parameters
    const url = new URL(dhruApiUrl);
    url.searchParams.append('action', 'getServices');
    url.searchParams.append('api_key', dhruApiKey);

    const dhruResponse = await fetch(url.toString(), {
      method: 'GET',
      headers: {
        'Content-Type': 'application/json'
      }
    });

    if (!dhruResponse.ok) {
      throw new Error(`Dhru API error: ${dhruResponse.status} ${dhruResponse.statusText}`);
    }

    const dhruData = await dhruResponse.json();

    // Validate response structure - handle both array and object responses
    const services = Array.isArray(dhruData) ? dhruData : (dhruData.services || dhruData.data || []);
    
    if (!Array.isArray(services) || services.length === 0) {
      throw new Error('Invalid Dhru API response: no services returned');
    }

    // Get all existing services from database
    const existingServices = await base44.asServiceRole.entities.Service.list();
    const existingServiceIds = new Set(existingServices.map(s => s.service_id));
    const dhruServiceIds = new Set(dhruData.services.map(s => String(s.id)));

    // Process each service from Dhru
    for (const dhruService of services) {
      const serviceId = String(dhruService.id);
      const providerPrice = parseFloat(dhruService.price || 0);
      const retailPrice = providerPrice + 0.50;

      const serviceData = {
        service_id: serviceId,
        service_name: dhruService.name || dhruService.service_name || 'Unknown Service',
        category: dhruService.category || 'Other',
        provider_price: providerPrice,
        retail_price: retailPrice,
        api_cost: providerPrice,
        price: retailPrice,
        delivery_time: dhruService.delivery_time || dhruService.deliveryTime || 'Standard',
        status: dhruService.status || 'active',
        is_active: (dhruService.status || 'active').toLowerCase() !== 'inactive',
        provider: 'dhru'
      };

      // Check if service exists
      const existingService = existingServices.find(s => s.service_id === serviceId);

      if (existingService) {
        // Update existing service
        await base44.asServiceRole.entities.Service.update(existingService.id, {
          service_name: serviceData.service_name,
          category: serviceData.category,
          provider_price: serviceData.provider_price,
          retail_price: serviceData.retail_price,
          api_cost: serviceData.api_cost,
          price: serviceData.price,
          delivery_time: serviceData.delivery_time,
          status: serviceData.status,
          is_active: serviceData.is_active
        });
        syncLog.services_updated++;
      } else {
        // Create new service
        await base44.asServiceRole.entities.Service.create(serviceData);
        syncLog.services_added++;
      }
    }

    // Deactivate services no longer in Dhru
    for (const existingService of existingServices) {
      // Only deactivate Dhru provider services
      if (existingService.provider === 'dhru' && !dhruServiceIds.has(existingService.service_id)) {
        await base44.asServiceRole.entities.Service.update(existingService.id, {
          is_active: false
        });
        syncLog.services_deactivated++;
      }
    }

    // Log the sync event
    await base44.asServiceRole.entities.SyncLog.create(syncLog);

    console.log(`Dhru sync completed: ${syncLog.services_added} added, ${syncLog.services_updated} updated, ${syncLog.services_deactivated} deactivated`);

    return Response.json({
      success: true,
      message: 'Dhru services synchronized successfully',
      ...syncLog
    });
  } catch (error) {
    console.error('Dhru sync error:', error.message);

    try {
      const base44 = createClientFromRequest(req);
      // Log failed sync
      await base44.asServiceRole.entities.SyncLog.create({
        timestamp: new Date().toISOString(),
        provider: 'dhru',
        services_updated: 0,
        services_added: 0,
        services_deactivated: 0,
        errors: error.message,
        status: 'failed'
      });
    } catch (logError) {
      console.error('Failed to log sync error:', logError.message);
    }

    return Response.json({
      success: false,
      error: error.message,
      details: 'Failed to sync Dhru services'
    }, { status: 500 });
  }
});