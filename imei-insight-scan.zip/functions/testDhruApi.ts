import { createClientFromRequest } from 'npm:@base44/sdk@0.8.20';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();

    if (user?.role !== 'admin') {
      return Response.json({ error: 'Forbidden' }, { status: 403 });
    }

    const apiKey = Deno.env.get('DHRU_API_KEY');
    const apiUrl = Deno.env.get('DHRU_API_URL');

    if (!apiKey || !apiUrl) {
      return Response.json({ error: 'Missing API credentials' }, { status: 400 });
    }

    const url = new URL(apiUrl);
    url.searchParams.append('action', 'getServices');
    url.searchParams.append('api_key', apiKey);

    console.log('Testing URL:', url.toString());

    const response = await fetch(url.toString(), {
      method: 'GET',
    });

    const text = await response.text();
    
    console.log('Response status:', response.status);
    console.log('Response text (first 500 chars):', text.substring(0, 500));

    return Response.json({
      status: response.status,
      contentType: response.headers.get('content-type'),
      textLength: text.length,
      preview: text.substring(0, 500),
    });
  } catch (error) {
    console.error('Error:', error);
    return Response.json({ error: error.message }, { status: 500 });
  }
});