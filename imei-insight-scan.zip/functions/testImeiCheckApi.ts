import { createClientFromRequest } from 'npm:@base44/sdk@0.8.20';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();

    if (user?.role !== 'admin') {
      return Response.json({ error: 'Forbidden' }, { status: 403 });
    }

    const apiKey = Deno.env.get('IMEICHECK_API_KEY');
    if (!apiKey) {
      return Response.json({ error: 'Missing IMEICHECK_API_KEY' }, { status: 400 });
    }

    // Test different endpoint variations
    const endpoints = [
      `https://alpha.imeicheck.com/api/php-api/create?key=${apiKey}&service=1&imei=123456789012345`,
      `https://api.imeicheck.com/api/php-api/create?key=${apiKey}&service=1&imei=123456789012345`,
      `https://imeicheck.com/api/php-api/create?key=${apiKey}&service=1&imei=123456789012345`,
    ];

    const results = [];

    for (const url of endpoints) {
      try {
        console.log('Testing:', url);
        const response = await fetch(url, { method: 'GET' });
        const text = await response.text();
        
        console.log('Response text:', text.substring(0, 200));
        
        let data = null;
        try {
          data = JSON.parse(text);
        } catch (e) {
          console.log('JSON parse error:', e.message);
        }

        results.push({
          url: url.split('key=')[0] + 'key=***',
          status: response.status,
          contentType: response.headers.get('content-type'),
          isJson: !!data,
          response: data || text.substring(0, 300),
        });
      } catch (err) {
        console.error('Fetch error:', err.message);
        results.push({
          url: url.split('key=')[0] + 'key=***',
          error: err.message,
        });
      }
    }

    return Response.json({ results });
  } catch (error) {
    console.error('Error:', error);
    return Response.json({ error: error.message }, { status: 500 });
  }
});